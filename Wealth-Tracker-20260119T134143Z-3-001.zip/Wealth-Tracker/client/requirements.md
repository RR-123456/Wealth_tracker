## Packages
recharts | For creating beautiful charts (Pie, Line, Bar) for net worth and cash flow analysis
lucide-react | For high-quality icons throughout the UI
framer-motion | For smooth page transitions and micro-interactions
date-fns | For date formatting in transaction lists and charts
clsx | For conditional class merging
tailwind-merge | For robust class merging

## Notes
- The app requires bilingual support (English/Tamil). I will implement a simple context for this.
- Authentication is handled via `useAuth` hook and Replit Auth.
- API requests use `credentials: "include"` for secure cookie handling.
- Charts need to be responsive to container width.
