import React from 'react';
import { Link, useLocation } from "wouter";
import { useLanguage } from '@/hooks/use-language';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { 
  LayoutDashboard, 
  Wallet, 
  Landmark, 
  ArrowLeftRight, 
  Calculator, 
  Bot, 
  LogOut,
  Menu,
  X,
  Languages
} from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { t, language, setLanguage } = useLanguage();
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [isOpen, setIsOpen] = React.useState(false);

  const navItems = [
    { href: '/', icon: LayoutDashboard, label: t('nav.dashboard') },
    { href: '/assets', icon: Wallet, label: t('nav.assets') },
    { href: '/liabilities', icon: Landmark, label: t('nav.liabilities') },
    { href: '/cashflow', icon: ArrowLeftRight, label: t('nav.cashflow') },
    { href: '/calculators', icon: Calculator, label: t('nav.calculators') },
    { href: '/ai-tools', icon: Bot, label: t('nav.ai') },
  ];

  const NavContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b border-border/10">
        <h1 className="text-2xl font-display font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
          WEALTHWISE
        </h1>
        <p className="text-[10px] leading-tight text-muted-foreground mt-1">
          W – Wealth<br/>
          E – Earnings<br/>
          A – Assets<br/>
          L – Liquidity<br/>
          T – Taxes<br/>
          H – Holdings<br/>
          W – Worth<br/>
          I – Investments<br/>
          S – Savings<br/>
          E – Expenses
        </p>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} className={`
              flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group
              ${isActive 
                ? 'bg-primary/10 text-primary font-medium' 
                : 'text-muted-foreground hover:bg-muted hover:text-foreground'}
            `}>
              <item.icon className={`w-5 h-5 ${isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground'}`} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border/10 space-y-4">
        {user && (
          <div className="flex items-center gap-3 px-4 py-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">
              {user.firstName?.[0] || user.email?.[0] || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.firstName} {user.lastName}</p>
              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
            </div>
          </div>
        )}

        <div className="flex gap-2">
            <Button 
                variant="outline" 
                size="sm" 
                className="flex-1"
                onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
            >
                <Languages className="w-4 h-4 mr-2" />
                {language === 'en' ? 'தமிழ்' : 'English'}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => logout()} title={t('nav.logout')}>
                <LogOut className="w-4 h-4 text-destructive" />
            </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-72 border-r bg-card/50 backdrop-blur-xl h-screen sticky top-0">
        <NavContent />
      </aside>

      {/* Mobile Sidebar */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b p-4 flex items-center justify-between">
        <h1 className="text-lg font-bold font-display text-primary">WEALTHWISE</h1>
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-72">
                <NavContent />
            </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-auto md:p-8 pt-20 p-4">
        <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {children}
        </div>
      </main>
    </div>
  );
}
