import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'ta';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<string, Record<Language, string>> = {
  // Navigation
  'nav.dashboard': { en: 'Dashboard', ta: 'முகப்பு' },
  'nav.assets': { en: 'Assets', ta: 'சொத்துக்கள்' },
  'nav.liabilities': { en: 'Liabilities', ta: 'பொறுப்புகள்' },
  'nav.cashflow': { en: 'Cash Flow', ta: 'பணப்புழக்கம்' },
  'nav.calculators': { en: 'Calculators', ta: 'கணிப்பான்கள்' },
  'nav.ai': { en: 'AI Tools', ta: 'AI கருவிகள்' },
  'nav.logout': { en: 'Logout', ta: 'வெளியேறு' },

  // Dashboard
  'dash.networth': { en: 'Net Worth', ta: 'நிகர மதிப்பு' },
  'dash.totalAssets': { en: 'Total Assets', ta: 'மொத்த சொத்துக்கள்' },
  'dash.totalLiabilities': { en: 'Total Liabilities', ta: 'மொத்த பொறுப்புகள்' },
  'dash.growth': { en: 'Growth', ta: 'வளர்ச்சி' },
  'dash.monthlySavings': { en: 'Est. Monthly Savings', ta: 'மாதாந்திர சேமிப்பு' },

  // Assets
  'assets.title': { en: 'Your Assets', ta: 'உங்கள் சொத்துக்கள்' },
  'assets.add': { en: 'Add Asset', ta: 'சொத்தைச் சேர்' },
  'assets.name': { en: 'Name', ta: 'பெயர்' },
  'assets.value': { en: 'Value', ta: 'மதிப்பு' },
  'assets.type': { en: 'Type', ta: 'வகை' },
  'assets.institution': { en: 'Institution', ta: 'நிறுவனம்' },

  // Liabilities
  'liabilities.title': { en: 'Your Liabilities', ta: 'உங்கள் பொறுப்புகள்' },
  'liabilities.add': { en: 'Add Liability', ta: 'பொறுப்பைச் சேர்' },
  'liabilities.outstanding': { en: 'Outstanding Amount', ta: 'நிலுவைத் தொகை' },
  'liabilities.monthlyPayment': { en: 'Monthly Payment', ta: 'மாதாந்திர தவணை' },

  // Generic
  'common.loading': { en: 'Loading...', ta: 'ஏற்றுகிறது...' },
  'common.save': { en: 'Save', ta: 'சேமி' },
  'common.cancel': { en: 'Cancel', ta: 'ரத்துசெய்' },
  'common.delete': { en: 'Delete', ta: 'நீக்கு' },
  'common.edit': { en: 'Edit', ta: 'திருத்து' },
  'common.error': { en: 'Error', ta: 'பிழை' },
  'common.success': { en: 'Success', ta: 'வெற்றி' },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
