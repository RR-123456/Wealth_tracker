import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { InsertLiability } from "@shared/schema";

export function useLiabilities() {
  return useQuery({
    queryKey: [api.liabilities.list.path],
    queryFn: async () => {
      const res = await fetch(api.liabilities.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch liabilities");
      return api.liabilities.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateLiability() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertLiability) => {
      const validated = api.liabilities.create.input.parse(data);
      const res = await fetch(api.liabilities.create.path, {
        method: api.liabilities.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create liability");
      return api.liabilities.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.liabilities.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.snapshots.list.path] });
    },
  });
}

export function useUpdateLiability() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...updates }: { id: number } & Partial<InsertLiability>) => {
      const url = buildUrl(api.liabilities.update.path, { id });
      const validated = api.liabilities.update.input.parse(updates);
      const res = await fetch(url, {
        method: api.liabilities.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update liability");
      return api.liabilities.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.liabilities.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.snapshots.list.path] });
    },
  });
}

export function useDeleteLiability() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.liabilities.delete.path, { id });
      const res = await fetch(url, {
        method: api.liabilities.delete.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to delete liability");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.liabilities.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.snapshots.list.path] });
    },
  });
}
