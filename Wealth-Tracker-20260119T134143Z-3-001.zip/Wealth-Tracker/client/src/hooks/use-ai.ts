import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { z } from "zod";

export function useAiStatementParser() {
  return useMutation({
    mutationFn: async (text: string) => {
      const res = await fetch(api.ai.parseStatement.path, {
        method: api.ai.parseStatement.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to parse statement");
      return api.ai.parseStatement.responses[200].parse(await res.json());
    },
  });
}

export function useAiNetWorthPredictor() {
  return useMutation({
    mutationFn: async (data: { currentNetWorth: number; monthlySaving: number; years: number }) => {
      const res = await fetch(api.ai.predictNetWorth.path, {
        method: api.ai.predictNetWorth.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to predict net worth");
      return api.ai.predictNetWorth.responses[200].parse(await res.json());
    },
  });
}
