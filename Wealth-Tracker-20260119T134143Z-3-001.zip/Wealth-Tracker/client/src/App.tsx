import React from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/hooks/use-language";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

// Pages
import Dashboard from "@/pages/dashboard";
import AssetsPage from "@/pages/assets";
import LiabilitiesPage from "@/pages/liabilities";
import CalculatorsPage from "@/pages/calculators";
import AiToolsPage from "@/pages/ai-tools";
import AuthPage from "@/pages/auth";
import Layout from "@/components/layout";
import NotFound from "@/pages/not-found";

import CashflowPage from "@/pages/cashflow";

function PrivateRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  return (
    <Layout>
      <Component />
    </Layout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => <PrivateRoute component={Dashboard} />} />
      <Route path="/assets" component={() => <PrivateRoute component={AssetsPage} />} />
      <Route path="/liabilities" component={() => <PrivateRoute component={LiabilitiesPage} />} />
      <Route path="/cashflow" component={() => <PrivateRoute component={CashflowPage} />} />
      <Route path="/calculators" component={() => <PrivateRoute component={CalculatorsPage} />} />
      <Route path="/ai-tools" component={() => <PrivateRoute component={AiToolsPage} />} />
      
      {/* Public Routes */}
      <Route path="/login" component={AuthPage} />
      
      {/* Fallback */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TooltipProvider>
            <Router />
            <Toaster />
        </TooltipProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
