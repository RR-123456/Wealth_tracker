import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowRight, ShieldCheck } from 'lucide-react';

export default function AuthPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <Card className="max-w-md w-full shadow-2xl border-0">
        <CardHeader className="text-center pb-2">
          <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="w-6 h-6 text-primary" />
          </div>
          <CardTitle className="text-2xl font-display font-bold text-primary">WealthWise</CardTitle>
          <CardDescription>Secure Net Worth & Cash Flow Tracker</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 pt-4">
            <div className="space-y-2 text-center text-sm text-muted-foreground">
                <p>Track Assets & Liabilities</p>
                <p>Analyze Cash Flow</p>
                <p>AI-Powered Predictions</p>
            </div>

            <Button 
                className="w-full h-12 text-lg font-medium shadow-lg hover:shadow-primary/25 transition-all"
                onClick={() => window.location.href = "/api/login"}
            >
                Login with Replit <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
            
            <p className="text-xs text-center text-muted-foreground pt-4">
                Secure authentication provided by Replit.
            </p>
        </CardContent>
      </Card>
    </div>
  );
}
