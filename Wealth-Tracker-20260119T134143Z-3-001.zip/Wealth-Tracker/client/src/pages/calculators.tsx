import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from '@/components/ui/label';
import { Calculator } from 'lucide-react';

export default function CalculatorsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Financial Calculators</h2>
        <p className="text-muted-foreground mt-1">Plan your future with these tools.</p>
      </div>

      <Tabs defaultValue="emi" className="w-full">
        <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
          <TabsTrigger value="emi">EMI</TabsTrigger>
          <TabsTrigger value="future">Future Value</TabsTrigger>
          <TabsTrigger value="loan">Loan Eligibility</TabsTrigger>
        </TabsList>
        <div className="mt-6">
          <TabsContent value="emi">
            <EmiCalculator />
          </TabsContent>
          <TabsContent value="future">
            <FutureValueCalculator />
          </TabsContent>
          <TabsContent value="loan">
            <LoanCalculator />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}

function EmiCalculator() {
  const [amount, setAmount] = useState(0);
  const [rate, setRate] = useState(0);
  const [years, setYears] = useState(0);
  const [emi, setEmi] = useState(0);

  const calculate = () => {
    if (amount <= 0 || rate <= 0 || years <= 0) return;
    const r = rate / 12 / 100;
    const n = years * 12;
    const val = amount * r * (Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    setEmi(val);
  };

  return (
    <Card>
      <CardHeader><CardTitle className="flex items-center gap-2"><Calculator className="w-5 h-5"/> EMI Calculator</CardTitle></CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 md:grid-cols-3">
          <div className="space-y-2">
            <Label>Loan Amount (RM)</Label>
            <Input type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label>Interest Rate (%)</Label>
            <Input type="number" value={rate} onChange={(e) => setRate(Number(e.target.value))} />
          </div>
          <div className="space-y-2">
            <Label>Tenure (Years)</Label>
            <Input type="number" value={years} onChange={(e) => setYears(Number(e.target.value))} />
          </div>
        </div>
        <Button onClick={calculate} className="w-full md:w-auto">Calculate</Button>
        
        {emi > 0 && (
          <div className="mt-6 p-4 bg-primary/5 rounded-xl border border-primary/20">
            <p className="text-sm text-muted-foreground">Monthly Installment</p>
            <p className="text-3xl font-bold text-primary">RM {emi.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function FutureValueCalculator() {
    const [principal, setPrincipal] = useState(0);
    const [rate, setRate] = useState(0);
    const [years, setYears] = useState(0);
    const [fv, setFv] = useState(0);

    const calculate = () => {
        if (principal <= 0 || rate <= 0 || years <= 0) return;
        // FV = PV * (1 + r)^n
        const val = principal * Math.pow((1 + rate/100), years);
        setFv(val);
    }

    return (
        <Card>
            <CardHeader><CardTitle>Future Value Calculator</CardTitle></CardHeader>
            <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                        <Label>Initial Investment (RM)</Label>
                        <Input type="number" value={principal} onChange={e => setPrincipal(Number(e.target.value))} />
                    </div>
                    <div className="space-y-2">
                        <Label>Annual Return (%)</Label>
                        <Input type="number" value={rate} onChange={e => setRate(Number(e.target.value))} />
                    </div>
                    <div className="space-y-2">
                        <Label>Years</Label>
                        <Input type="number" value={years} onChange={e => setYears(Number(e.target.value))} />
                    </div>
                </div>
                <Button onClick={calculate}>Calculate</Button>
                {fv > 0 && (
                    <div className="mt-6 p-4 bg-green-500/10 rounded-xl border border-green-500/20">
                        <p className="text-sm text-muted-foreground">Future Value</p>
                        <p className="text-3xl font-bold text-green-600">RM {fv.toLocaleString(undefined, { maximumFractionDigits: 2 })}</p>
                    </div>
                )}
            </CardContent>
        </Card>
    )
}

function LoanCalculator() {
    return (
        <Card>
            <CardHeader><CardTitle>Loan Eligibility</CardTitle></CardHeader>
            <CardContent>
                <p className="text-muted-foreground">Coming soon...</p>
            </CardContent>
        </Card>
    )
}
