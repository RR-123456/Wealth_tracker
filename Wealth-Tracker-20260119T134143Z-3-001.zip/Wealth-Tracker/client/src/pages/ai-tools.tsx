import React, { useState } from 'react';
import { useAiStatementParser, useAiNetWorthPredictor } from '@/hooks/use-ai';
import { useAssets } from '@/hooks/use-assets';
import { useLiabilities } from '@/hooks/use-liabilities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Bot, FileText, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function AiToolsPage() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">F.I.N.A.S.S.I.S.</h2>
        <p className="text-muted-foreground mt-1">
          Financial Intelligent Navigator Assistant Supporting Smart Investment Solutions
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        <StatementParser />
        <NetWorthPredictor />
      </div>
    </div>
  );
}

function StatementParser() {
  const [text, setText] = useState('');
  const { mutate, isPending, data } = useAiStatementParser();

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><FileText className="w-5 h-5 text-blue-500"/> Bank Statement Parser</CardTitle>
        <CardDescription>Paste your bank statement text here. AI will extract transactions.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea 
          placeholder="Date | Description | Amount..." 
          className="min-h-[200px] font-mono text-xs"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <Button 
          onClick={() => mutate(text)} 
          disabled={isPending || !text}
          className="w-full"
        >
          {isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <Bot className="w-4 h-4 mr-2"/>}
          Parse Transactions
        </Button>

        {data && (
          <div className="mt-4 p-4 bg-muted rounded-lg border border-border">
            <h4 className="font-semibold mb-2">Found {data.transactions.length} Transactions:</h4>
            <div className="space-y-2 max-h-[200px] overflow-auto">
              {data.transactions.map((tx: any, i: number) => (
                <div key={i} className="text-sm flex justify-between p-2 bg-background rounded border">
                  <span>{tx.description}</span>
                  <span className={tx.type === 'income' ? 'text-green-600' : 'text-red-600'}>
                    {tx.amount}
                  </span>
                </div>
              ))}
            </div>
            <Button variant="secondary" className="w-full mt-4">Import to Cash Flow</Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function NetWorthPredictor() {
  const [password, setPassword] = useState('');
  const [isProtected, setIsProtected] = useState(false);
  const { mutate, isPending, data } = useAiNetWorthPredictor();
  const { data: assets } = useAssets();
  const { data: liabilities } = useLiabilities();

  const handlePredict = () => {
    const currentNetWorth = (assets?.reduce((s, a) => s + Number(a.value), 0) || 0) - 
                          (liabilities?.reduce((s, l) => s + Number(l.outstandingAmount), 0) || 0);
    
    mutate({
      currentNetWorth,
      monthlySaving: 2000, // Ideally calculate from transactions
      years: 5,
      password: password || undefined
    });
  };

  const chartData = data ? Object.entries(data.predictions).map(([year, amount]) => ({
    year,
    amount
  })) : [];

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><TrendingUp className="w-5 h-5 text-purple-500"/> NETPRO</CardTitle>
        <CardDescription>
          Network Evaluation Trends Prediction Resource Optimizer
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-muted/50 p-4 rounded-lg space-y-2">
            <div className="flex justify-between text-sm">
                <span>Current Net Worth:</span>
                <span className="font-mono">RM {((assets?.reduce((s, a) => s + Number(a.value), 0) || 0) - (liabilities?.reduce((s, l) => s + Number(l.outstandingAmount), 0) || 0)).toLocaleString()}</span>
            </div>
            <div className="space-y-2 pt-2">
              <Label htmlFor="prediction-password">Secure with Password (Optional)</Label>
              <Input 
                id="prediction-password"
                type="password" 
                placeholder="Enter password to lock" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
        </div>

        <Button onClick={handlePredict} disabled={isPending} className="w-full bg-purple-600 hover:bg-purple-700">
          {isPending && <Loader2 className="w-4 h-4 animate-spin mr-2"/>}
          Generate Prediction
        </Button>

        {data && (
          <div className="h-[250px] w-full mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis dataKey="year" fontSize={12} />
                <YAxis fontSize={12} tickFormatter={(val) => `${val/1000}k`} />
                <Tooltip formatter={(val: number) => `RM ${val.toLocaleString()}`} />
                <Line type="monotone" dataKey="amount" stroke="#8b5cf6" strokeWidth={3} dot={{r: 4}} />
              </LineChart>
            </ResponsiveContainer>
            <p className="text-center text-xs text-muted-foreground mt-2">
                Confidence Score: {(data.confidence * 100).toFixed(0)}%
            </p>
            <Button variant="outline" size="sm" className="w-full mt-2" onClick={() => {/* Save logic */}}>
              Save Prediction Details
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
