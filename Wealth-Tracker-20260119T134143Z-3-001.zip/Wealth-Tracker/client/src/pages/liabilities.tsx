import React, { useState } from 'react';
import { useLiabilities, useCreateLiability, useUpdateLiability, useDeleteLiability } from '@/hooks/use-liabilities';
import { useLanguage } from '@/hooks/use-language';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, Plus, Pencil, Trash2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertLiabilitySchema, type InsertLiability, type Liability } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

export default function LiabilitiesPage() {
  const { t } = useLanguage();
  const { data: liabilities, isLoading } = useLiabilities();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Liability | null>(null);

  if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">{t('liabilities.title')}</h2>
          <p className="text-muted-foreground mt-1">Track your loans and debts.</p>
        </div>
        <Button onClick={() => { setEditingItem(null); setIsDialogOpen(true); }} className="gap-2">
          <Plus className="w-4 h-4" /> {t('liabilities.add')}
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('assets.name')}</TableHead>
                <TableHead>{t('assets.type')}</TableHead>
                <TableHead className="text-right">{t('liabilities.outstanding')}</TableHead>
                <TableHead className="text-right">{t('liabilities.monthlyPayment')}</TableHead>
                <TableHead className="w-[100px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {liabilities?.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell className="capitalize text-muted-foreground">{item.type.replace('_', ' ')}</TableCell>
                  <TableCell className="text-right font-semibold text-red-600">RM {Number(item.outstandingAmount).toLocaleString()}</TableCell>
                  <TableCell className="text-right">RM {Number(item.monthlyPayment || 0).toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex gap-2 justify-end">
                      <Button variant="ghost" size="icon" onClick={() => { setEditingItem(item); setIsDialogOpen(true); }}>
                        <Pencil className="w-4 h-4 text-blue-500" />
                      </Button>
                      <DeleteButton id={item.id} />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {liabilities?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    No liabilities found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <LiabilityDialog 
        open={isDialogOpen} 
        onOpenChange={setIsDialogOpen} 
        item={editingItem}
      />
    </div>
  );
}

function DeleteButton({ id }: { id: number }) {
  const { mutate, isPending } = useDeleteLiability();
  const { toast } = useToast();

  return (
    <Button 
      variant="ghost" 
      size="icon" 
      disabled={isPending}
      onClick={() => {
        if(confirm('Delete this liability?')) {
          mutate(id, {
            onSuccess: () => toast({ title: "Liability deleted" }),
            onError: () => toast({ title: "Failed to delete", variant: "destructive" })
          });
        }
      }}
    >
      {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4 text-red-500" />}
    </Button>
  );
}

function LiabilityDialog({ open, onOpenChange, item }: { open: boolean, onOpenChange: (open: boolean) => void, item: Liability | null }) {
  const { t } = useLanguage();
  const createMutation = useCreateLiability();
  const updateMutation = useUpdateLiability();
  const { toast } = useToast();

  const form = useForm<InsertLiability>({
    resolver: zodResolver(insertLiabilitySchema),
    defaultValues: item || {
      name: '',
      type: 'personal_loan',
      outstandingAmount: 0,
      monthlyPayment: 0,
      interestRate: 0,
      currency: 'MYR',
      description: ''
    }
  });

  React.useEffect(() => {
    if (open) {
      form.reset(item || {
        name: '',
        type: 'personal_loan',
        outstandingAmount: 0,
        monthlyPayment: 0,
        interestRate: 0,
        currency: 'MYR',
        description: ''
      });
    }
  }, [open, item, form]);

  const onSubmit = (data: InsertLiability) => {
    const mutation = item ? updateMutation : createMutation;
    const payload = item ? { id: item.id, ...data } : data;

    // @ts-ignore
    mutation.mutate(payload, {
      onSuccess: () => {
        toast({ title: item ? "Liability updated" : "Liability created", className: "bg-green-500 text-white" });
        onOpenChange(false);
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{item ? t('common.edit') : t('liabilities.add')}</DialogTitle>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">{t('assets.name')}</label>
            <Input {...form.register('name')} placeholder="e.g. Car Loan" />
            {form.formState.errors.name && <span className="text-xs text-red-500">{form.formState.errors.name.message}</span>}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">{t('assets.type')}</label>
            <Select onValueChange={(val) => form.setValue('type', val)} defaultValue={form.getValues('type')}>
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="housing_loan">Housing loan</SelectItem>
                <SelectItem value="car_loan">Car loan</SelectItem>
                <SelectItem value="student_loan">Student loan</SelectItem>
                <SelectItem value="personal_loan">Personal loan</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">{t('liabilities.outstanding')}</label>
              <Input 
                type="number" 
                step="0.01" 
                {...form.register('outstandingAmount', { valueAsNumber: true })} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">{t('liabilities.monthlyPayment')}</label>
              <Input 
                type="number" 
                step="0.01" 
                {...form.register('monthlyPayment', { valueAsNumber: true })} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Currency</label>
              <Select onValueChange={(val) => form.setValue('currency', val)} defaultValue={form.getValues('currency')}>
                <SelectTrigger>
                  <SelectValue placeholder="Currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MYR">MYR (RM)</SelectItem>
                  <SelectItem value="SGD">SGD (S$)</SelectItem>
                  <SelectItem value="USD">USD ($)</SelectItem>
                  <SelectItem value="INR">INR (₹)</SelectItem>
                  <SelectItem value="EUR">EUR (€)</SelectItem>
                  <SelectItem value="GBP">GBP (£)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
            
          <div className="space-y-2">
            <label className="text-sm font-medium">Interest Rate (%)</label>
            <Input 
              type="number" 
              step="0.1" 
              {...form.register('interestRate', { valueAsNumber: true })} 
              placeholder="e.g. 3.5"
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary">
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {t('common.save')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
