import React from 'react';
import { useAssets } from '@/hooks/use-assets';
import { useLiabilities } from '@/hooks/use-liabilities';
import { useLanguage } from '@/hooks/use-language';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, TrendingUp, TrendingDown, DollarSign, PiggyBank } from 'lucide-react';
import { format } from 'date-fns';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend,
  BarChart, Bar, XAxis, YAxis, CartesianGrid
} from 'recharts';

export default function Dashboard() {
  const { t } = useLanguage();
  const { data: assets, isLoading: assetsLoading } = useAssets();
  const { data: liabilities, isLoading: liabilitiesLoading } = useLiabilities();
  const currentTime = new Date();

  if (assetsLoading || liabilitiesLoading) {
    return (
      <div className="h-[50vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const totalAssets = assets?.reduce((sum, item) => sum + Number(item.value), 0) || 0;
  const totalLiabilities = liabilities?.reduce((sum, item) => sum + Number(item.outstandingAmount), 0) || 0;
  const netWorth = totalAssets - totalLiabilities;
  const isPositive = netWorth >= 0;

  const assetData = assets?.map(a => ({ name: a.name, value: Number(a.value) })) || [];
  const liabilityData = liabilities?.map(l => ({ name: l.name, value: Number(l.outstandingAmount) })) || [];

  // Grouped breakdown for chart display based on your requested structure
  const assetBreakdown = [
    { name: 'Saving accounts', value: assets?.filter(a => a.type === 'saving').reduce((s, a) => s + Number(a.value), 0) || 0 },
    { name: 'Investments', value: assets?.filter(a => a.type === 'investment').reduce((s, a) => s + Number(a.value), 0) || 0 },
    { name: 'Fixed deposit', value: assets?.filter(a => a.type === 'fixed_deposit').reduce((s, a) => s + Number(a.value), 0) || 0 },
    { name: 'EPF', value: assets?.filter(a => a.type === 'epf').reduce((s, a) => s + Number(a.value), 0) || 0 },
    { name: 'Unit trust', value: assets?.filter(a => a.type === 'unit_trust').reduce((s, a) => s + Number(a.value), 0) || 0 },
    { name: 'Property', value: assets?.filter(a => a.type === 'property').reduce((s, a) => s + Number(a.value), 0) || 0 },
    { name: 'Vehicle', value: assets?.filter(a => a.type === 'vehicle').reduce((s, a) => s + Number(a.value), 0) || 0 },
    { name: 'Other', value: assets?.filter(a => a.type === 'other').reduce((s, a) => s + Number(a.value), 0) || 0 },
  ].filter(i => i.value > 0);

  const liabilityBreakdown = [
    { name: 'Housing loan', value: liabilities?.filter(l => l.type === 'housing_loan').reduce((s, l) => s + Number(l.outstandingAmount), 0) || 0 },
    { name: 'Car loan', value: liabilities?.filter(l => l.type === 'car_loan').reduce((s, l) => s + Number(l.outstandingAmount), 0) || 0 },
    { name: 'Student loan', value: liabilities?.filter(l => l.type === 'student_loan').reduce((s, l) => s + Number(l.outstandingAmount), 0) || 0 },
    { name: 'Personal loan', value: liabilities?.filter(l => l.type === 'personal_loan').reduce((s, l) => s + Number(l.outstandingAmount), 0) || 0 },
  ].filter(i => i.value > 0);

  // Color Psychology: Blue, Black, Red
  const COLORS = ['#1a365d', '#000000', '#c53030', '#2b6cb0', '#2d3748', '#e53e3e', '#718096', '#cbd5e0'];

  // Summary data for combined graph
  const combinedData = [
    { name: 'Income', amount: 0, color: '#1a365d' },
    { name: 'Expenses', amount: 0, color: '#c53030' },
    { name: 'EMI', amount: liabilities?.reduce((s, l) => s + Number(l.monthlyPayment || 0), 0) || 0, color: '#000000' },
    { name: 'Loan', amount: totalLiabilities, color: '#2d3748' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">{t('nav.dashboard')}</h2>
          <p className="text-muted-foreground mt-1">
            {format(currentTime, 'PPPP p')}
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="card-hover bg-white border-silver shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-black">
              Current Net Worth
            </CardTitle>
            <DollarSign className="h-4 w-4 text-blue-900" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${isPositive ? 'text-blue-900' : 'text-red-700'}`}>
              RM {netWorth.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Total financial position</p>
          </CardContent>
        </Card>

        <Card className="card-hover bg-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Assets</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">RM {totalAssets.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">Across {assets?.length || 0} items</p>
          </CardContent>
        </Card>

        <Card className="card-hover bg-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Liabilities</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-700" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">RM {totalLiabilities.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">Across {liabilities?.length || 0} loans</p>
          </CardContent>
        </Card>

        <Card className="card-hover bg-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">NW Growth Rate</CardTitle>
            <PiggyBank className="h-4 w-4 text-black" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">0%</div>
            <p className="text-xs text-muted-foreground mt-1">Annual projection</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Asset Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {assetBreakdown.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                    data={assetBreakdown}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    >
                    {assetBreakdown.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                    </Pie>
                    <Tooltip 
                        formatter={(value: number) => `RM ${value.toLocaleString()}`}
                        contentStyle={{ backgroundColor: 'var(--card)', borderRadius: '8px', border: '1px solid var(--border)' }}
                    />
                    <Legend />
                </PieChart>
                </ResponsiveContainer>
            ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
                    No assets recorded yet.
                </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Liability Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {liabilityBreakdown.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                    data={liabilityBreakdown}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    >
                    {liabilityBreakdown.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                    </Pie>
                    <Tooltip 
                        formatter={(value: number) => `RM ${value.toLocaleString()}`}
                        contentStyle={{ backgroundColor: 'var(--card)', borderRadius: '8px', border: '1px solid var(--border)' }}
                    />
                    <Legend />
                </PieChart>
                </ResponsiveContainer>
            ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
                    No liabilities recorded yet.
                </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="w-full">
        <CardHeader>
          <CardTitle>Financial Performance Overview (Income, Expenses, EMI, Loan)</CardTitle>
        </CardHeader>
        <CardContent className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={combinedData}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                formatter={(value: number) => `RM ${value.toLocaleString()}`}
                contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e2e8f0' }}
              />
              <Bar dataKey="amount">
                {combinedData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>{t('assets.title')}</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {assetData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                    data={assetData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    >
                    {assetData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                    </Pie>
                    <Tooltip 
                        formatter={(value: number) => `RM ${value.toLocaleString()}`}
                        contentStyle={{ backgroundColor: 'var(--card)', borderRadius: '8px', border: '1px solid var(--border)' }}
                    />
                    <Legend />
                </PieChart>
                </ResponsiveContainer>
            ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
                    No assets recorded yet.
                </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>{t('liabilities.title')}</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {liabilityData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                    data={liabilityData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    >
                    {liabilityData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                    </Pie>
                    <Tooltip 
                        formatter={(value: number) => `RM ${value.toLocaleString()}`}
                        contentStyle={{ backgroundColor: 'var(--card)', borderRadius: '8px', border: '1px solid var(--border)' }}
                    />
                    <Legend />
                </PieChart>
                </ResponsiveContainer>
            ) : (
                <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
                    No liabilities recorded yet.
                </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
