import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, Plus, Trash2, ArrowUpCircle, ArrowDownCircle } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertTransactionSchema, type Transaction, type InsertTransaction } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export default function CashflowPage() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: transactions, isLoading } = useQuery<Transaction[]>({ 
    queryKey: ['/api/transactions'] 
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/transactions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      toast({ title: "Transaction deleted" });
    }
  });

  if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin text-primary" /></div>;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Cash Flow</h2>
          <p className="text-muted-foreground mt-1">Track your income and expenses.</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 bg-primary">
              <Plus className="w-4 h-4" /> Add Transaction
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Add Transaction</DialogTitle>
            </DialogHeader>
            <TransactionForm onSuccess={() => setIsDialogOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <SummaryCard 
          title="Total Income" 
          amount={transactions?.filter(t => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0) || 0}
          icon={<ArrowUpCircle className="text-blue-600" />}
        />
        <SummaryCard 
          title="Total Expenses" 
          amount={transactions?.filter(t => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0) || 0}
          icon={<ArrowDownCircle className="text-red-600" />}
        />
        <SummaryCard 
          title="Net Cash Flow" 
          amount={(transactions?.filter(t => t.type === 'income').reduce((s, t) => s + Number(t.amount), 0) || 0) - 
                  (transactions?.filter(t => t.type === 'expense').reduce((s, t) => s + Number(t.amount), 0) || 0)}
          icon={<div className="w-4 h-4 bg-black rounded-full" />}
        />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions?.map((tx) => (
                <TableRow key={tx.id}>
                  <TableCell>{format(new Date(tx.date), 'MMM d, yyyy')}</TableCell>
                  <TableCell className="font-medium">{tx.description}</TableCell>
                  <TableCell className="capitalize text-muted-foreground">{tx.category.replace('_', ' ')}</TableCell>
                  <TableCell className={`text-right font-semibold ${tx.type === 'income' ? 'text-blue-700' : 'text-red-700'}`}>
                    {tx.type === 'income' ? '+' : '-'} RM {Number(tx.amount).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => deleteMutation.mutate(tx.id)}
                      disabled={deleteMutation.isPending}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function SummaryCard({ title, amount, icon }: { title: string, amount: number, icon: React.ReactNode }) {
  return (
    <Card className="bg-white border-silver">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">RM {amount.toLocaleString()}</div>
      </CardContent>
    </Card>
  );
}

function TransactionForm({ onSuccess }: { onSuccess: () => void }) {
  const { toast } = useToast();
  const form = useForm<InsertTransaction>({
    resolver: zodResolver(insertTransactionSchema),
    defaultValues: {
      description: '',
      amount: 0,
      type: 'expense',
      category: 'food',
      date: new Date(),
      currency: 'MYR'
    }
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertTransaction) => {
      await apiRequest('POST', '/api/transactions', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/transactions'] });
      toast({ title: "Transaction added" });
      onSuccess();
    }
  });

  return (
    <form onSubmit={form.handleSubmit((data) => mutation.mutate(data))} className="space-y-4 pt-4">
      <div className="space-y-2">
        <label className="text-sm font-medium">Description</label>
        <Input {...form.register('description')} placeholder="e.g. Salary, Groceries" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Type</label>
          <Select onValueChange={(val) => form.setValue('type', val)} defaultValue="expense">
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="income">Income</SelectItem>
              <SelectItem value="expense">Expense</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Amount</label>
          <Input type="number" step="0.01" {...form.register('amount', { valueAsNumber: true })} />
        </div>
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium">Category</label>
        <Input {...form.register('category')} placeholder="e.g. Salary, Food, Rent" />
      </div>
      <Button type="submit" className="w-full bg-primary" disabled={mutation.isPending}>
        {mutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Transaction"}
      </Button>
    </form>
  );
}
