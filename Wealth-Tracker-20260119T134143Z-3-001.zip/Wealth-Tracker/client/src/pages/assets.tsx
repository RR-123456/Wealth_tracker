import React, { useState } from 'react';
import { useAssets, useCreateAsset, useUpdateAsset, useDeleteAsset } from '@/hooks/use-assets';
import { useLanguage } from '@/hooks/use-language';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, Plus, Pencil, Trash2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertAssetSchema, type InsertAsset, type Asset } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

export default function AssetsPage() {
  const { t } = useLanguage();
  const { data: assets, isLoading } = useAssets();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);

  if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">{t('assets.title')}</h2>
          <p className="text-muted-foreground mt-1">Manage your wealth portfolio.</p>
        </div>
        <Button onClick={() => { setEditingAsset(null); setIsDialogOpen(true); }} className="gap-2">
          <Plus className="w-4 h-4" /> {t('assets.add')}
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{t('assets.name')}</TableHead>
                <TableHead>{t('assets.type')}</TableHead>
                <TableHead>{t('assets.institution')}</TableHead>
                <TableHead className="text-right">{t('assets.value')}</TableHead>
                <TableHead className="w-[100px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assets?.map((asset) => (
                <TableRow key={asset.id}>
                  <TableCell className="font-medium">{asset.name}</TableCell>
                  <TableCell className="capitalize text-muted-foreground">{asset.type.replace('_', ' ')}</TableCell>
                  <TableCell>{asset.institution || '-'}</TableCell>
                  <TableCell className="text-right font-semibold">RM {Number(asset.value).toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex gap-2 justify-end">
                      <Button variant="ghost" size="icon" onClick={() => { setEditingAsset(asset); setIsDialogOpen(true); }}>
                        <Pencil className="w-4 h-4 text-blue-500" />
                      </Button>
                      <DeleteButton id={asset.id} />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {assets?.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    No assets found. Add your first asset to get started.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <AssetDialog 
        open={isDialogOpen} 
        onOpenChange={setIsDialogOpen} 
        asset={editingAsset}
      />
    </div>
  );
}

function DeleteButton({ id }: { id: number }) {
  const { mutate, isPending } = useDeleteAsset();
  const { toast } = useToast();

  return (
    <Button 
      variant="ghost" 
      size="icon" 
      disabled={isPending}
      onClick={() => {
        if(confirm('Are you sure you want to delete this asset?')) {
          mutate(id, {
            onSuccess: () => toast({ title: "Asset deleted" }),
            onError: () => toast({ title: "Failed to delete", variant: "destructive" })
          });
        }
      }}
    >
      {isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4 text-red-500" />}
    </Button>
  );
}

function AssetDialog({ open, onOpenChange, asset }: { open: boolean, onOpenChange: (open: boolean) => void, asset: Asset | null }) {
  const { t } = useLanguage();
  const createMutation = useCreateAsset();
  const updateMutation = useUpdateAsset();
  const { toast } = useToast();

  const form = useForm<InsertAsset>({
    resolver: zodResolver(insertAssetSchema),
    defaultValues: asset || {
      name: '',
      type: 'saving',
      value: 0,
      currency: 'MYR',
      institution: '',
      description: ''
    }
  });

  // Reset form when dialog opens/closes or asset changes
  React.useEffect(() => {
    if (open) {
      form.reset(asset || {
        name: '',
        type: 'saving',
        value: 0,
        currency: 'MYR',
        institution: '',
        description: ''
      });
    }
  }, [open, asset, form]);

  const onSubmit = (data: InsertAsset) => {
    const mutation = asset ? updateMutation : createMutation;
    const payload = asset ? { id: asset.id, ...data } : data;

    // @ts-ignore
    mutation.mutate(payload, {
      onSuccess: () => {
        toast({ title: asset ? "Asset updated" : "Asset created", className: "bg-green-500 text-white" });
        onOpenChange(false);
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{asset ? t('common.edit') : t('assets.add')}</DialogTitle>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">{t('assets.name')}</label>
            <Input {...form.register('name')} placeholder="e.g. Maybank Savings" />
            {form.formState.errors.name && <span className="text-xs text-red-500">{form.formState.errors.name.message}</span>}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">{t('assets.type')}</label>
            <Select onValueChange={(val) => form.setValue('type', val)} defaultValue={form.getValues('type')}>
              <SelectTrigger>
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="saving">Saving accounts</SelectItem>
                <SelectItem value="investment">Investments</SelectItem>
                <SelectItem value="fixed_deposit">Fixed deposit</SelectItem>
                <SelectItem value="epf">EPF</SelectItem>
                <SelectItem value="unit_trust">Unit trust / mutual funds</SelectItem>
                <SelectItem value="property">Housing property</SelectItem>
                <SelectItem value="vehicle">Vehicle</SelectItem>
                <SelectItem value="other">Other asset</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">{t('assets.value')}</label>
              <Input 
                type="number" 
                step="0.01" 
                {...form.register('value', { valueAsNumber: true })} 
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Currency</label>
              <Select onValueChange={(val) => form.setValue('currency', val)} defaultValue={form.getValues('currency')}>
                <SelectTrigger>
                  <SelectValue placeholder="Currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MYR">MYR (RM)</SelectItem>
                  <SelectItem value="SGD">SGD (S$)</SelectItem>
                  <SelectItem value="USD">USD ($)</SelectItem>
                  <SelectItem value="INR">INR (₹)</SelectItem>
                  <SelectItem value="EUR">EUR (€)</SelectItem>
                  <SelectItem value="GBP">GBP (£)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">{t('assets.institution')}</label>
            <Input {...form.register('institution')} placeholder="Optional" />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              {t('common.cancel')}
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary">
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {t('common.save')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
