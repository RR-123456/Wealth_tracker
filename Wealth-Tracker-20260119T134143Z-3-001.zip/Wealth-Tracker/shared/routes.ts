import { z } from 'zod';
import { insertAssetSchema, insertLiabilitySchema, insertTransactionSchema, assets, liabilities, transactions, snapshots } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  assets: {
    list: {
      method: 'GET' as const,
      path: '/api/assets',
      responses: {
        200: z.array(z.custom<typeof assets.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/assets',
      input: insertAssetSchema,
      responses: {
        201: z.custom<typeof assets.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/assets/:id',
      input: insertAssetSchema.partial(),
      responses: {
        200: z.custom<typeof assets.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/assets/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  liabilities: {
    list: {
      method: 'GET' as const,
      path: '/api/liabilities',
      responses: {
        200: z.array(z.custom<typeof liabilities.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/liabilities',
      input: insertLiabilitySchema,
      responses: {
        201: z.custom<typeof liabilities.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/liabilities/:id',
      input: insertLiabilitySchema.partial(),
      responses: {
        200: z.custom<typeof liabilities.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/liabilities/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  transactions: {
    list: {
      method: 'GET' as const,
      path: '/api/transactions',
      responses: {
        200: z.array(z.custom<typeof transactions.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/transactions',
      input: insertTransactionSchema,
      responses: {
        201: z.custom<typeof transactions.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/transactions/:id',
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  snapshots: {
    list: {
      method: 'GET' as const,
      path: '/api/snapshots',
      responses: {
        200: z.array(z.custom<typeof snapshots.$inferSelect>()),
      },
    },
  },
  ai: {
    parseStatement: {
      method: 'POST' as const,
      path: '/api/ai/parse-statement',
      input: z.object({
        text: z.string(),
      }),
      responses: {
        200: z.object({
          transactions: z.array(insertTransactionSchema),
        }),
      },
    },
    predictNetWorth: {
      method: 'POST' as const,
      path: '/api/ai/predict-net-worth',
      input: z.object({
        currentNetWorth: z.number(),
        monthlySaving: z.number(),
        years: z.number().default(3),
      }),
      responses: {
        200: z.object({
          predictions: z.record(z.number()), // year -> amount
          confidence: z.number(),
        }),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
