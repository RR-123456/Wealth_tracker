import { pgTable, text, serial, integer, numeric, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export * from "./models/auth";
export * from "./models/chat";

export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(), 
  name: text("name").notNull(),
  type: text("type").notNull(), // 'saving', 'investment', 'fixed_deposit', 'epf', 'unit_trust', 'property', 'vehicle', 'other'
  value: numeric("value").notNull(),
  currency: text("currency").default("MYR").notNull(), // 'MYR', 'SGD', 'USD', 'INR', 'EUR', 'GBP'
  institution: text("institution"),
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const liabilities = pgTable("liabilities", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'housing_loan', 'car_loan', 'student_loan', 'personal_loan'
  outstandingAmount: numeric("outstanding_amount").notNull(),
  monthlyPayment: numeric("monthly_payment"),
  interestRate: numeric("interest_rate"),
  currency: text("currency").default("MYR").notNull(), // 'MYR', 'SGD', 'USD', 'INR', 'EUR', 'GBP'
  description: text("description"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  date: timestamp("date").notNull(),
  type: text("type").notNull(), // 'income', 'expense', 'investment'
  category: text("category").notNull(), // 'salary', 'bonus', 'dividend', 'rental', 'freelance', 'water', 'electricity', etc.
  amount: numeric("amount").notNull(),
  description: text("description"),
  currency: text("currency").default("MYR").notNull(), // 'MYR', 'SGD', 'USD', 'INR', 'EUR', 'GBP'
});

export const snapshots = pgTable("snapshots", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  date: timestamp("date").defaultNow(),
  netWorth: numeric("net_worth").notNull(),
  totalAssets: numeric("total_assets").notNull(),
  totalLiabilities: numeric("total_liabilities").notNull(),
  predictions: jsonb("predictions"), // Store prediction details
  password: text("password"), // Optional password for prediction
});

// Schemas
export const insertAssetSchema = createInsertSchema(assets).omit({ id: true, updatedAt: true });
export const insertLiabilitySchema = createInsertSchema(liabilities).omit({ id: true, updatedAt: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true });
export const insertSnapshotSchema = createInsertSchema(snapshots).omit({ id: true, date: true });

// Types
export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type Liability = typeof liabilities.$inferSelect;
export type InsertLiability = z.infer<typeof insertLiabilitySchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Snapshot = typeof snapshots.$inferSelect;
export type InsertSnapshot = z.infer<typeof insertSnapshotSchema>;
