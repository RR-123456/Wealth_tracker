import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { registerAudioRoutes } from "./replit_integrations/audio";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth Setup
  await setupAuth(app);
  registerAuthRoutes(app);
  
  // Register other integrations
  registerChatRoutes(app);
  registerImageRoutes(app);
  registerAudioRoutes(app);

  // Helper to get user ID from request (claims from Replit Auth)
  const getUserId = (req: any) => {
    return req.user?.claims?.sub;
  };

  // Middleware to ensure authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  // --- Assets ---
  app.get(api.assets.list.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    const assets = await storage.getAssets(userId);
    res.json(assets);
  });

  app.post(api.assets.create.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    try {
      const input = api.assets.create.input.parse({ ...req.body, userId });
      const asset = await storage.createAsset(input);
      res.status(201).json(asset);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.put(api.assets.update.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    try {
      const input = api.assets.update.input.parse(req.body);
      const updated = await storage.updateAsset(Number(req.params.id), userId, input);
      if (!updated) return res.status(404).json({ message: "Asset not found" });
      res.json(updated);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.delete(api.assets.delete.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    await storage.deleteAsset(Number(req.params.id), userId);
    res.status(204).send();
  });

  // --- Liabilities ---
  app.get(api.liabilities.list.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    const result = await storage.getLiabilities(userId);
    res.json(result);
  });

  app.post(api.liabilities.create.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    try {
      const input = api.liabilities.create.input.parse({ ...req.body, userId });
      const result = await storage.createLiability(input);
      res.status(201).json(result);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.put(api.liabilities.update.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    try {
      const input = api.liabilities.update.input.parse(req.body);
      const updated = await storage.updateLiability(Number(req.params.id), userId, input);
      if (!updated) return res.status(404).json({ message: "Liability not found" });
      res.json(updated);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.delete(api.liabilities.delete.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    await storage.deleteLiability(Number(req.params.id), userId);
    res.status(204).send();
  });

  // --- Transactions ---
  app.get(api.transactions.list.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    const result = await storage.getTransactions(userId);
    res.json(result);
  });

  app.post(api.transactions.create.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    try {
      const input = api.transactions.create.input.parse({ ...req.body, userId });
      const result = await storage.createTransaction(input);
      res.status(201).json(result);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.delete(api.transactions.delete.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    await storage.deleteTransaction(Number(req.params.id), userId);
    res.status(204).send();
  });

  // --- Snapshots ---
  app.get(api.snapshots.list.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    const result = await storage.getSnapshots(userId);
    res.json(result);
  });

  // --- AI Tools ---
  app.post(api.ai.parseStatement.path, requireAuth, async (req, res) => {
    const userId = getUserId(req);
    const { text } = req.body;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          {
            role: "system",
            content: "You are a financial assistant. Extract transactions from the bank statement text provided. Return a JSON object with a key 'transactions' which is an array of objects. Each object should have: 'date' (ISO string), 'type' (income or expense), 'category' (e.g., salary, food, transport), 'amount' (number), 'description' (string). guess category based on description."
          },
          {
            role: "user",
            content: text
          }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      // Add userId to transactions
      const transactions = (result.transactions || []).map((t: any) => ({
        ...t,
        userId,
        currency: "MYR" // Default currency
      }));
      
      res.json({ transactions });
    } catch (error) {
      console.error("AI Parse Error:", error);
      res.status(500).json({ message: "Failed to parse statement" });
    }
  });

  app.post(api.ai.predictNetWorth.path, requireAuth, async (req, res) => {
    const { currentNetWorth, monthlySaving, years } = req.body;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [
          {
            role: "system",
            content: "Predict net worth for future years. Return a JSON object with keys 'predictions' (year -> value map) and 'confidence' (0-100 number). Assume moderate market growth for investments."
          },
          {
            role: "user",
            content: `Current Net Worth: ${currentNetWorth}. Monthly Saving: ${monthlySaving}. Predict for next ${years} years.`
          }
        ],
        response_format: { type: "json_object" }
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      res.json(result);
    } catch (error) {
      console.error("AI Predict Error:", error);
      res.status(500).json({ message: "Failed to predict net worth" });
    }
  });

  return httpServer;
}
