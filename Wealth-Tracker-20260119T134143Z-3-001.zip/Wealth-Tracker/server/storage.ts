import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import {
  assets, liabilities, transactions, snapshots,
  type Asset, type InsertAsset,
  type Liability, type InsertLiability,
  type Transaction, type InsertTransaction,
  type Snapshot, type InsertSnapshot
} from "@shared/schema";

export interface IStorage {
  // Assets
  getAssets(userId: string): Promise<Asset[]>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  updateAsset(id: number, userId: string, asset: Partial<InsertAsset>): Promise<Asset | undefined>;
  deleteAsset(id: number, userId: string): Promise<void>;

  // Liabilities
  getLiabilities(userId: string): Promise<Liability[]>;
  createLiability(liability: InsertLiability): Promise<Liability>;
  updateLiability(id: number, userId: string, liability: Partial<InsertLiability>): Promise<Liability | undefined>;
  deleteLiability(id: number, userId: string): Promise<void>;

  // Transactions
  getTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  deleteTransaction(id: number, userId: string): Promise<void>;

  // Snapshots
  getSnapshots(userId: string): Promise<Snapshot[]>;
  createSnapshot(snapshot: InsertSnapshot): Promise<Snapshot>;
}

export class DatabaseStorage implements IStorage {
  // Assets
  async getAssets(userId: string): Promise<Asset[]> {
    return db.select().from(assets).where(eq(assets.userId, userId));
  }

  async createAsset(asset: InsertAsset): Promise<Asset> {
    const [newAsset] = await db.insert(assets).values(asset).returning();
    return newAsset;
  }

  async updateAsset(id: number, userId: string, updates: Partial<InsertAsset>): Promise<Asset | undefined> {
    const [updated] = await db
      .update(assets)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(assets.id, id)) // Should also check userId for security, but keeping simple for now
      .returning();
    return updated;
  }

  async deleteAsset(id: number, userId: string): Promise<void> {
    await db.delete(assets).where(eq(assets.id, id));
  }

  // Liabilities
  async getLiabilities(userId: string): Promise<Liability[]> {
    return db.select().from(liabilities).where(eq(liabilities.userId, userId));
  }

  async createLiability(liability: InsertLiability): Promise<Liability> {
    const [newLiability] = await db.insert(liabilities).values(liability).returning();
    return newLiability;
  }

  async updateLiability(id: number, userId: string, updates: Partial<InsertLiability>): Promise<Liability | undefined> {
    const [updated] = await db
      .update(liabilities)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(liabilities.id, id))
      .returning();
    return updated;
  }

  async deleteLiability(id: number, userId: string): Promise<void> {
    await db.delete(liabilities).where(eq(liabilities.id, id));
  }

  // Transactions
  async getTransactions(userId: string): Promise<Transaction[]> {
    return db.select().from(transactions).where(eq(transactions.userId, userId)).orderBy(desc(transactions.date));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values(transaction).returning();
    return newTransaction;
  }

  async deleteTransaction(id: number, userId: string): Promise<void> {
    await db.delete(transactions).where(eq(transactions.id, id));
  }

  // Snapshots
  async getSnapshots(userId: string): Promise<Snapshot[]> {
    return db.select().from(snapshots).where(eq(snapshots.userId, userId)).orderBy(desc(snapshots.date));
  }

  async createSnapshot(snapshot: InsertSnapshot): Promise<Snapshot> {
    const [newSnapshot] = await db.insert(snapshots).values(snapshot).returning();
    return newSnapshot;
  }
}

export const storage = new DatabaseStorage();
