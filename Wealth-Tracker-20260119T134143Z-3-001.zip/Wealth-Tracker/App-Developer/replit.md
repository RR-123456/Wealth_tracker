# MutMonMortMan AlgoAnalAutoAIML TrustTechTradeTransact RevReliRegReport InnovInterInvestIntegrative ExpoExqXChangeExpertiseSystem (MATRIX Bank)

## Overview

MATRIX Bank is a modern fintech web application that simulates a banking system with features including account management, deposits, withdrawals, transfers, loan processing, scheduled transactions, and AI-powered balance predictions. The application follows a full-stack TypeScript architecture with a React frontend and Express backend, using PostgreSQL for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state, React Context for auth and language
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens for a fintech aesthetic
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Build Tool**: Vite with HMR support

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Design**: RESTful endpoints with Zod schema validation
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions

### Data Layer
- **Database**: PostgreSQL (required via DATABASE_URL environment variable)
- **Schema Location**: `shared/schema.ts` - contains table definitions and Zod validation schemas
- **Migrations**: Drizzle Kit with `db:push` command for schema synchronization

### Shared Code Pattern
The `shared/` directory contains code used by both frontend and backend:
- `schema.ts`: Database table definitions, TypeScript types, and validation schemas
- `routes.ts`: API contract definitions with typed request/response schemas

### Key Design Decisions

**Monorepo Structure**: Single repository with `client/`, `server/`, and `shared/` directories enables type sharing across the stack without build complexity.

**Type-Safe API Contract**: The `shared/routes.ts` file defines the complete API contract with Zod schemas, ensuring runtime validation matches compile-time types.

**Component Library**: Uses shadcn/ui (new-york style) for consistent, accessible UI components. Components are copied into `client/src/components/ui/` for customization.

**Multi-Language Support**: Built-in internationalization context supporting English and Tamil translations.

### Build System
- **Development**: `npm run dev` - runs tsx directly for fast iteration
- **Production**: `npm run build` - uses esbuild for server bundling and Vite for client, outputs to `dist/`
- **Type Checking**: `npm run check` - TypeScript validation without emit

## External Dependencies

### Database
- **PostgreSQL**: Required database, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Schema management and query building
- **connect-pg-simple**: Session storage in PostgreSQL

### Frontend Libraries
- **@tanstack/react-query**: Async state management and caching
- **Radix UI**: Accessible component primitives (dialog, dropdown, popover, etc.)
- **Framer Motion**: Animation library
- **date-fns**: Date formatting and manipulation
- **recharts**: Data visualization for balance predictions

### Development Tools
- **Vite**: Frontend build and dev server with React plugin
- **esbuild**: Server bundling for production
- **Drizzle Kit**: Database migration tooling
- **TypeScript**: Type checking across the entire codebase

### Configuration Files
- `components.json`: shadcn/ui configuration pointing to client source paths
- `drizzle.config.ts`: Database connection and migration output settings
- `tailwind.config.ts`: Extended color palette and custom border radius values
- `vite.config.ts`: Path aliases (@/, @shared/, @assets/) and Replit-specific plugins