import { z } from 'zod';
import { 
  insertAccountSchema, 
  accounts, 
  transactions, 
  depositWithdrawSchema, 
  transferSchema, 
  scheduleTransactionSchema,
  smartBalanceSchema
} from './schema';

// === SHARED ERROR SCHEMAS ===
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  business: z.object({
    message: z.string(),
  })
};

// === API CONTRACT ===
export const api = {
  accounts: {
    create: {
      method: 'POST' as const,
      path: '/api/accounts',
      input: insertAccountSchema,
      responses: {
        201: z.custom<typeof accounts.$inferSelect>(),
        400: errorSchemas.validation,
        409: errorSchemas.business // Account exists
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/accounts', // Protected by developer code in headers or query? keeping simple
      responses: {
        200: z.array(z.custom<typeof accounts.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/accounts/:accNo',
      responses: {
        200: z.custom<typeof accounts.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    verify: {
      method: 'POST' as const,
      path: '/api/accounts/verify',
      input: z.object({ accNo: z.string(), pin: z.coerce.number() }),
      responses: {
        200: z.object({ verified: z.boolean(), account: z.custom<typeof accounts.$inferSelect>().optional() }),
      }
    }
  },
  transactions: {
    process: {
      method: 'POST' as const,
      path: '/api/transactions/process', // Handle Deposit/Withdraw immediate
      input: depositWithdrawSchema,
      responses: {
        200: z.object({ 
          success: z.boolean(), 
          newBalance: z.number(), 
          message: z.string() 
        }),
        400: errorSchemas.business, // Insufficient funds etc
        401: errorSchemas.unauthorized
      }
    },
    transfer: {
      method: 'POST' as const,
      path: '/api/transactions/transfer',
      input: transferSchema,
      responses: {
        200: z.object({ 
          success: z.boolean(), 
          newBalance: z.number(), 
          message: z.string() 
        }),
        400: errorSchemas.business,
        401: errorSchemas.unauthorized
      }
    },
    schedule: {
      method: 'POST' as const,
      path: '/api/transactions/schedule',
      input: scheduleTransactionSchema,
      responses: {
        201: z.object({ message: z.string(), id: z.number() }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized
      }
    },
    cancel: {
      method: 'POST' as const,
      path: '/api/transactions/:id/cancel',
      input: z.object({ accNo: z.string(), pin: z.coerce.number() }),
      responses: {
        200: z.object({ message: z.string() }),
        404: errorSchemas.notFound,
        401: errorSchemas.unauthorized
      }
    },
    history: {
      method: 'GET' as const,
      path: '/api/transactions/history/:accNo', // Ideally verified by header/session, but simplest to just list public or verify pin in body (GET body bad practice). We'll assume for this simple app, we just fetch by ID. In real app, we'd use session.
      responses: {
        200: z.array(z.custom<typeof transactions.$inferSelect>()),
      }
    }
  },
  tools: {
    smartBalance: {
      method: 'POST' as const,
      path: '/api/tools/smart-balance',
      input: smartBalanceSchema,
      responses: {
        200: z.any(),
        401: errorSchemas.unauthorized
      }
    },
    developer: {
      export: {
        method: 'POST' as const,
        path: '/api/developer/export',
        input: z.object({ code: z.string() }),
        responses: {
          200: z.object({ accounts: z.array(z.any()), transactions: z.array(z.any()) }),
          403: errorSchemas.unauthorized
        }
      },
      reset: {
        method: 'POST' as const,
        path: '/api/developer/reset',
        input: z.object({ code: z.string() }),
        responses: {
          200: z.object({ message: z.string() }),
          403: errorSchemas.unauthorized
        }
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
