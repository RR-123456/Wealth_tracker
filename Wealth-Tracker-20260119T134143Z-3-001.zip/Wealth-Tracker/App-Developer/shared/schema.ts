import { pgTable, text, serial, integer, boolean, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  accNo: text("acc_no").notNull().unique(),
  name: text("name").notNull(),
  balance: numeric("balance", { precision: 12, scale: 2 }).notNull().default("0"),
  pin: integer("pin").notNull(),
  loanAmount: numeric("loan_amount", { precision: 12, scale: 2 }).notNull().default("0"),
  loanStartDate: timestamp("loan_start_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // DEPOSIT, WITHDRAW, TRANSFER, LOAN_CREDIT, LOAN_REPAY
  fromAcc: text("from_acc").notNull(),
  toAcc: text("to_acc"),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  fee: numeric("fee", { precision: 12, scale: 2 }).default("0"),
  isScheduled: boolean("is_scheduled").default(false),
  scheduledFor: timestamp("scheduled_for"),
  createdAt: timestamp("created_at").defaultNow(),
  executedAt: timestamp("executed_at"),
  status: text("status").default("completed"),
});

// === SCHEMAS ===
export const insertAccountSchema = createInsertSchema(accounts).omit({ 
  id: true, 
  createdAt: true, 
  balance: true,
  loanAmount: true,
  loanStartDate: true
}).extend({
  initialBalance: z.number().min(0).optional(),
  pin: z.coerce.number().min(1000).max(999999),
  accNo: z.string().min(1)
});

export const scheduleTransactionSchema = z.object({
  fromAcc: z.string(),
  pin: z.coerce.number(),
  type: z.enum(["DEPOSIT", "WITHDRAW", "TRANSFER"]),
  toAcc: z.string().optional(),
  amount: z.coerce.number().positive(),
  scheduledFor: z.string(), // ISO date string
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  executedAt: true
});

// === EXPLICIT API CONTRACT TYPES ===
export type Account = typeof accounts.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;

export type CreateAccountRequest = z.infer<typeof insertAccountSchema>;

export const depositWithdrawSchema = z.object({
  accNo: z.string(),
  pin: z.coerce.number(),
  amount: z.coerce.number().positive(),
  type: z.enum(["DEPOSIT", "WITHDRAW", "LOAN_CREDIT", "LOAN_REPAY"])
});
export type DepositWithdrawRequest = z.infer<typeof depositWithdrawSchema>;

export const transferSchema = z.object({
  fromAcc: z.string(),
  pin: z.coerce.number(),
  toAcc: z.string(),
  amount: z.coerce.number().positive(),
  isScheduled: z.boolean().optional(),
  scheduledFor: z.string().optional(),
});
export type TransferRequest = z.infer<typeof transferSchema>;

export const smartBalanceSchema = z.object({
  accNo: z.string(),
  pin: z.coerce.number(),
  targetDate: z.string(),
});
export type SmartBalanceRequest = z.infer<typeof smartBalanceSchema>;

export type ScheduleTransactionRequest = z.infer<typeof scheduleTransactionSchema>;

export type SmartBalanceResponse = {
  currentBalance: number;
  scheduledDeposits: number;
  scheduledWithdrawals: number;
  projectedFees: number;
  predictedBalance: number;
  confidence: number;
  avgMonthlyIncoming: number;
  avgMonthlyOutgoing: number;
  avgDailyIncoming: number;
  avgDailyOutgoing: number;
  activeLoan: {
    amount: number;
    interest: number;
    penalty: number;
    totalDue: number;
    dueDate: string;
  } | null;
  matrixValues: {
    scheduled_transfers: number;
    taxes: number;
    credit_amt: number;
    interest: number;
    penalties: number;
    ml_adjustment: number;
    calculated_balance: number;
  };
};
