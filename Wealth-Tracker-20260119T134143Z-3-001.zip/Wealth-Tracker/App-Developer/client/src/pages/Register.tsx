import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useCreateAccount } from "@/hooks/use-banking";
import { useAuth } from "@/context/AuthContext";
import { ShinyButton } from "@/components/ui/shiny-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Building2, ArrowRight } from "lucide-react";

export default function Register() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { mutateAsync: createAccount, isPending, error } = useCreateAccount();
  
  const [formData, setFormData] = useState({
    name: "",
    accNo: "",
    pin: "",
    initialBalance: "0"
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const newAccount = await createAccount({
        name: formData.name,
        accNo: formData.accNo,
        pin: parseInt(formData.pin),
        initialBalance: parseFloat(formData.initialBalance)
      });
      login(newAccount);
      setLocation("/dashboard");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <Link href="/" className="mb-8 flex items-center gap-2 text-slate-900 hover:opacity-80 transition-opacity">
        <Building2 className="w-8 h-8 text-primary" />
        <span className="font-display font-bold text-2xl">GDB Online</span>
      </Link>

      <Card className="w-full max-w-md border-slate-200 shadow-xl">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-display font-bold">Create an account</CardTitle>
          <CardDescription>Enter your details to open a new GDB account.</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-50 text-red-600 text-sm font-medium border border-red-100">
                {error.message}
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input 
                id="name" 
                placeholder="John Doe" 
                required 
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="accNo">Account Number</Label>
              <Input 
                id="accNo" 
                placeholder="Create a unique ID (e.g. user123)" 
                required 
                value={formData.accNo}
                onChange={e => setFormData({...formData, accNo: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pin">Secure PIN (4-6 digits)</Label>
              <Input 
                id="pin" 
                type="password" 
                placeholder="1234" 
                maxLength={6}
                required 
                value={formData.pin}
                onChange={e => setFormData({...formData, pin: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="balance">Initial Deposit ($)</Label>
              <Input 
                id="balance" 
                type="number" 
                min="0" 
                placeholder="0.00" 
                value={formData.initialBalance}
                onChange={e => setFormData({...formData, initialBalance: e.target.value})}
              />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <ShinyButton className="w-full" disabled={isPending}>
              {isPending ? "Creating..." : "Create Account"}
            </ShinyButton>
            <div className="text-center text-sm text-slate-500">
              Already have an account?{" "}
              <Link href="/login">
                <span className="text-primary font-semibold hover:underline cursor-pointer">
                  Access it here
                </span>
              </Link>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
