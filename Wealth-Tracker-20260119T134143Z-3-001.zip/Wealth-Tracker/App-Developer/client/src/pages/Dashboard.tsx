import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { useAccount, useTransactionHistory } from "@/hooks/use-banking";
import { SmartBalanceCard } from "@/components/SmartBalanceCard";
import { TransactionModal } from "@/components/TransactionModal";
import { ShinyButton } from "@/components/ui/shiny-button";
import { ArrowUpRight, ArrowDownLeft, ArrowRightLeft, History, LogOut, Globe } from "lucide-react";
import { format } from "date-fns";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export default function Dashboard() {
  const { account, logout } = useAuth();
  const { t, setLanguage, language } = useLanguage();
  const [, setLocation] = useLocation();
  
  // Real-time data fetching
  const { data: latestAccount } = useAccount(account?.accNo);
  const { data: history } = useTransactionHistory(account?.accNo);

  // Redirect if not logged in
  useEffect(() => {
    if (!account) setLocation("/login");
  }, [account, setLocation]);

  if (!account) return null;

  // Use latest account data if available, fall back to context data
  const currentAccount = latestAccount || account;

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      {/* Dashboard Header */}
      <header className="bg-white/80 backdrop-blur-xl border-b sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-blue-400 font-black text-xl shadow-lg shadow-blue-500/10">
              {currentAccount.name.charAt(0)}
            </div>
            <div>
              <p className="text-sm font-black text-slate-900 uppercase tracking-tight leading-none mb-1">{currentAccount.name}</p>
              <div className="flex items-center gap-2">
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-50 text-blue-600 font-bold uppercase tracking-widest">Active</span>
                <p className="text-[10px] text-slate-400 font-bold font-mono tracking-widest uppercase">{currentAccount.accNo}</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="h-10 px-4 rounded-xl bg-slate-50 border border-slate-200 hover:bg-white hover:border-blue-500 text-slate-600 transition-all flex items-center gap-2 group shadow-sm">
                  <Globe className="w-4 h-4 group-hover:text-blue-600 transition-colors" />
                  <span className="text-[10px] font-black uppercase tracking-widest">{language}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40 rounded-xl p-1 border-slate-200">
                <DropdownMenuItem className="rounded-lg font-bold text-xs uppercase tracking-widest" onClick={() => setLanguage("en")}>English</DropdownMenuItem>
                <DropdownMenuItem className="rounded-lg font-bold text-xs uppercase tracking-widest" onClick={() => setLanguage("ta")}>தமிழ் (Tamil)</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <button 
              onClick={logout}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-900 text-white hover:bg-red-600 transition-all shadow-lg shadow-red-500/10 active:scale-95"
              title={t("logout")}
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
        
        {/* Balance Section */}
        <section className="grid md:grid-cols-2 gap-10">
          <div className="space-y-8">
            <div className="bg-white p-10 rounded-[2rem] border-2 border-slate-100 shadow-xl shadow-slate-200/50 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:bg-blue-100 transition-colors" />
              
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-4">
                  <p className="text-slate-400 text-xs font-black uppercase tracking-[0.2em]">{t("totalBalance")}</p>
                  {Number(currentAccount.loanAmount) > 0 && (
                    <div className="px-4 py-1.5 bg-red-50 text-red-600 text-[10px] font-black rounded-full border border-red-100 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse" />
                      {t("activeLoan").toUpperCase()}
                    </div>
                  )}
                </div>
                <h1 className="text-7xl font-black text-slate-900 tracking-tighter mb-10 leading-none">
                  <span className="text-3xl text-slate-300 font-medium mr-1">$</span>
                  {Number(currentAccount.balance).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </h1>
                
                <div className="flex gap-4 flex-wrap">
                  <TransactionModal 
                    type="DEPOSIT" 
                    trigger={
                      <button className="h-14 px-8 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl shadow-blue-500/20 active:scale-95 flex items-center gap-3">
                        <ArrowDownLeft className="w-4 h-4" /> {t("deposit")}
                      </button>
                    } 
                  />
                  <TransactionModal 
                    type="WITHDRAW" 
                    trigger={
                      <button className="h-14 px-8 bg-white text-slate-900 border-2 border-slate-200 rounded-2xl font-black text-xs uppercase tracking-widest hover:border-red-500 hover:text-red-600 transition-all active:scale-95 flex items-center gap-3 shadow-sm">
                        <ArrowUpRight className="w-4 h-4" /> {t("withdraw")}
                      </button>
                    } 
                  />
                  <TransactionModal 
                    type="TRANSFER" 
                    trigger={
                      <button className="h-14 px-8 bg-slate-50 text-slate-900 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-50 hover:text-blue-600 transition-all active:scale-95 flex items-center gap-3 shadow-sm">
                        <ArrowRightLeft className="w-4 h-4" /> {t("transfer")}
                      </button>
                    } 
                  />
                </div>
                
                <div className="mt-10 pt-8 border-t border-slate-100 flex gap-6 flex-wrap">
                  <TransactionModal 
                    type="LOAN_CREDIT" 
                    trigger={
                      <button className="text-[10px] font-black text-blue-600 hover:text-blue-700 uppercase tracking-[0.15em] flex items-center gap-2 group">
                        <div className="w-6 h-6 rounded-lg bg-blue-50 flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                          <ArrowDownLeft className="w-3 h-3" />
                        </div>
                        {t("loanCredit")}
                      </button>
                    } 
                  />
                  <TransactionModal 
                    type="LOAN_REPAY" 
                    trigger={
                      <button className="text-[10px] font-black text-amber-500 hover:text-amber-600 uppercase tracking-[0.15em] flex items-center gap-2 group">
                        <div className="w-6 h-6 rounded-lg bg-amber-50 flex items-center justify-center group-hover:bg-amber-100 transition-colors">
                          <ArrowUpRight className="w-3 h-3" />
                        </div>
                        {t("loanRepay")}
                      </button>
                    } 
                  />
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-slate-900 p-8 rounded-3xl shadow-xl shadow-blue-500/10 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl" />
                <p className="text-blue-400 font-black text-2xl mb-1 tracking-tight">4.2%</p>
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">APY Interest</p>
              </div>
              <div className="bg-white p-8 rounded-3xl border-2 border-slate-100 shadow-lg shadow-slate-200/50">
                <p className="text-slate-900 font-black text-2xl mb-1 tracking-tight">Level 2</p>
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Protocol Tier</p>
              </div>
            </div>
          </div>

          {/* Smart Balance Card */}
          <SmartBalanceCard accNo={currentAccount.accNo} pin={currentAccount.pin} />
        </section>

        {/* Transaction History */}
        <section className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500">
                <History className="w-5 h-5" />
              </div>
              {t("recentTransactions")}
            </h2>
          </div>

          <div className="bg-white rounded-[2rem] border-2 border-slate-100 shadow-xl shadow-slate-200/50 overflow-hidden">
            {!history || history.length === 0 ? (
              <div className="py-24 text-center">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-300">
                  <History className="w-10 h-10" />
                </div>
                <p className="text-slate-400 font-black text-xs uppercase tracking-widest">System idle. No data logs found.</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {history.map((tx) => (
                  <div key={tx.id} className="p-8 hover:bg-slate-50 transition-all flex items-center justify-between group">
                    <div className="flex items-center gap-6">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110 ${
                        tx.type === 'DEPOSIT' || tx.type === 'LOAN_CREDIT' ? 'bg-green-50 text-green-600' :
                        tx.type === 'WITHDRAW' || tx.type === 'LOAN_REPAY' ? 'bg-red-50 text-red-600' :
                        'bg-blue-50 text-blue-600'
                      }`}>
                        {(tx.type === 'DEPOSIT' || tx.type === 'LOAN_CREDIT') && <ArrowDownLeft className="w-6 h-6" />}
                        {(tx.type === 'WITHDRAW' || tx.type === 'LOAN_REPAY') && <ArrowUpRight className="w-6 h-6" />}
                        {tx.type === 'TRANSFER' && <ArrowRightLeft className="w-6 h-6" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-black text-slate-900 uppercase tracking-tight">{t(tx.type.toLowerCase())}</p>
                          {tx.isScheduled && (
                            <span className="text-[8px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-600 font-black uppercase tracking-widest border border-amber-100">Scheduled</span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">
                          {tx.executedAt ? format(new Date(tx.executedAt), "dd MMM yyyy • HH:mm") : 'Pending Verification'}
                        </p>
                      </div>
                    </div>
                    <div className={`text-right font-mono font-black text-xl tracking-tighter ${
                      tx.type === 'DEPOSIT' || tx.type === 'LOAN_CREDIT' ? 'text-green-600' : 'text-slate-900'
                    }`}>
                      <span className="text-sm mr-0.5">{(tx.type === 'DEPOSIT' || tx.type === 'LOAN_CREDIT') ? '+' : '-'}</span>
                      {Number(tx.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      {tx.type === 'TRANSFER' && (
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
                          {tx.fromAcc === currentAccount.accNo ? `→ ${tx.toAcc}` : `← ${tx.fromAcc}`}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
