import { Link } from "wouter";
import { ShinyButton } from "@/components/ui/shiny-button";
import { motion } from "framer-motion";
import { Building2, ShieldCheck, Zap, TrendingUp, Cpu, Globe, Lock } from "lucide-react";

export default function Landing() {
  const matrixItems = [
    { letter: "M", title: "Mutual", subtitle: "Monetary, Mortgage, Management", color: "text-slate-900" },
    { letter: "A", title: "Algorithmic", subtitle: "Analytics, Auto, AI, ML", color: "text-blue-600" },
    { letter: "T", title: "Trustable", subtitle: "Technical, Trading, Transfer, Transaction", color: "text-slate-900" },
    { letter: "R", title: "Revenue", subtitle: "Reliability, Regulatory, Reporting", color: "text-amber-500" },
    { letter: "I", title: "Innovative", subtitle: "Inter, Invest, Integrative", color: "text-slate-900" },
    { letter: "X", title: "Exponential", subtitle: "Execute, Changeable, Expertise, System", color: "text-blue-600" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans overflow-x-hidden">
      {/* Navbar */}
      <nav className="border-b bg-white/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <motion.div 
              whileHover={{ rotate: 10 }}
              className="bg-slate-900 p-2.5 rounded-xl shadow-lg shadow-blue-500/20"
            >
              <Building2 className="w-7 h-7 text-blue-400" />
            </motion.div>
            <div className="flex flex-col">
              <span className="font-display font-black text-2xl tracking-tighter text-slate-900 leading-none">MATRIX</span>
              <span className="text-[10px] font-bold text-blue-600 tracking-widest uppercase">Ecosystem</span>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <Link href="/login">
              <span className="text-sm font-bold text-slate-600 hover:text-blue-600 cursor-pointer transition-colors uppercase tracking-wider">
                Access
              </span>
            </Link>
            <Link href="/register">
              <ShinyButton className="px-6 py-2.5 bg-slate-900 text-white hover:bg-blue-600 border-none rounded-full shadow-xl shadow-blue-500/20 transition-all">
                Open Account
              </ShinyButton>
            </Link>
          </div>
        </div>
      </nav>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative pt-20 pb-32 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1200px] h-[800px] bg-gradient-to-b from-blue-100/50 to-transparent rounded-full blur-[120px] -z-10" />
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-20">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
                className="inline-block px-4 py-1.5 mb-6 rounded-full bg-blue-50 border border-blue-100 text-blue-600 text-xs font-bold tracking-widest uppercase"
              >
                The Future of Decentralized Finance
              </motion.div>
              
              <motion.h1 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.8 }}
                className="text-6xl md:text-8xl font-black text-slate-900 tracking-tight leading-[0.9] mb-8"
              >
                Intelligent <span className="text-blue-600">Wealth</span> <br />
                Architecture.
              </motion.h1>

              <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.8 }}
                className="max-w-3xl mx-auto text-xl text-slate-500 leading-relaxed mb-12"
              >
                A high-performance financial operating system engineered for the next generation of global capital.
              </motion.p>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.8 }}
                className="flex flex-wrap justify-center gap-6"
              >
                <Link href="/register">
                  <ShinyButton className="text-lg px-10 py-5 bg-slate-900 text-white rounded-2xl shadow-2xl shadow-blue-500/40 hover:scale-105 transition-transform">
                    Initialize Account
                  </ShinyButton>
                </Link>
                <Link href="/developer">
                  <button className="text-lg px-10 py-5 font-bold text-slate-900 border-2 border-slate-200 rounded-2xl hover:border-blue-500 transition-all hover:bg-white active:scale-95">
                    Terminal Access
                  </button>
                </Link>
              </motion.div>
            </div>

            {/* Matrix Abbreviation Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-slate-200 rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
              {matrixItems.map((item, idx) => (
                <motion.div
                  key={item.letter}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.1 * idx }}
                  className="bg-white p-10 group hover:bg-slate-50 transition-colors cursor-default"
                >
                  <div className="flex items-start gap-6">
                    <span className={`text-6xl font-black ${item.color} opacity-20 group-hover:opacity-100 transition-opacity leading-none`}>
                      {item.letter}
                    </span>
                    <div className="pt-2">
                      <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight mb-2">
                        {item.title}
                      </h3>
                      <p className="text-sm text-slate-500 font-medium leading-snug">
                        {item.subtitle}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="bg-slate-900 py-32 relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent opacity-50" />
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="grid lg:grid-cols-3 gap-16">
              <div className="space-y-6">
                <div className="w-16 h-16 bg-blue-500/20 rounded-2xl flex items-center justify-center border border-blue-500/30">
                  <Lock className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight">Quantum Security</h3>
                <p className="text-slate-400 leading-relaxed">Cryptographic asset protection engineered for maximum reliability and regulatory compliance.</p>
              </div>
              <div className="space-y-6">
                <div className="w-16 h-16 bg-amber-500/20 rounded-2xl flex items-center justify-center border border-amber-500/30">
                  <Cpu className="w-8 h-8 text-amber-400" />
                </div>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight">AI Governance</h3>
                <p className="text-slate-400 leading-relaxed">Algorithmic risk management and automated portfolio optimization for consistent performance.</p>
              </div>
              <div className="space-y-6">
                <div className="w-16 h-16 bg-blue-500/20 rounded-2xl flex items-center justify-center border border-blue-500/30">
                  <Globe className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-2xl font-black text-white uppercase tracking-tight">Global Liquidity</h3>
                <p className="text-slate-400 leading-relaxed">High-frequency trading infrastructure providing instant cross-border settlement and exchange.</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-white border-t py-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-10">
            <div className="flex items-center gap-3">
              <div className="bg-slate-900 p-2 rounded-lg">
                <Building2 className="w-5 h-5 text-blue-400" />
              </div>
              <span className="font-black text-xl tracking-tighter text-slate-900">MATRIX</span>
            </div>
            <div className="text-slate-400 text-sm font-bold tracking-widest uppercase">
              © {new Date().getFullYear()} Matrix Financial Ecosystem. All protocols active.
            </div>
            <div className="flex gap-8">
              <span className="text-xs font-black text-slate-900 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">Privacy</span>
              <span className="text-xs font-black text-slate-900 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">Terms</span>
              <span className="text-xs font-black text-slate-900 uppercase tracking-widest cursor-pointer hover:text-blue-600 transition-colors">Security</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
