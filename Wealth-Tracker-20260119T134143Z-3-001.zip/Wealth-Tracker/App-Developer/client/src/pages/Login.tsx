import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useVerifyAccount } from "@/hooks/use-banking";
import { useAuth } from "@/context/AuthContext";
import { ShinyButton } from "@/components/ui/shiny-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Building2, LockKeyhole } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { mutateAsync: verify, isPending, error } = useVerifyAccount();
  
  const [formData, setFormData] = useState({
    accNo: "",
    pin: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const result = await verify({
        accNo: formData.accNo,
        pin: parseInt(formData.pin)
      });
      
      if (result.verified && result.account) {
        login(result.account);
        setLocation("/dashboard");
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <Link href="/" className="mb-8 flex items-center gap-2 text-slate-900 hover:opacity-80 transition-opacity">
        <Building2 className="w-8 h-8 text-primary" />
        <span className="font-display font-bold text-2xl">GDB Online</span>
      </Link>

      <Card className="w-full max-w-md border-slate-200 shadow-xl">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-display font-bold">Welcome back</CardTitle>
          <CardDescription>Access your secure banking terminal.</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-red-50 text-red-600 text-sm font-medium border border-red-100 flex items-center gap-2">
                <LockKeyhole className="w-4 h-4" />
                {error.message}
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="accNo">Account Number</Label>
              <Input 
                id="accNo" 
                placeholder="Enter your account ID" 
                required 
                value={formData.accNo}
                onChange={e => setFormData({...formData, accNo: e.target.value})}
                className="font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pin">PIN Code</Label>
              <Input 
                id="pin" 
                type="password" 
                placeholder="••••" 
                maxLength={6}
                required 
                value={formData.pin}
                onChange={e => setFormData({...formData, pin: e.target.value})}
                className="font-mono tracking-widest"
              />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-4">
            <ShinyButton className="w-full" disabled={isPending}>
              {isPending ? "Verifying..." : "Access Account"}
            </ShinyButton>
            <div className="text-center text-sm text-slate-500">
              New to GDB Online?{" "}
              <Link href="/register">
                <span className="text-primary font-semibold hover:underline cursor-pointer">
                  Open an account
                </span>
              </Link>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
