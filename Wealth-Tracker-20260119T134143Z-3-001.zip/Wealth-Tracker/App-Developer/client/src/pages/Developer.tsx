import { useState } from "react";
import { Link } from "wouter";
import { useDeveloperExport, useDeveloperReset } from "@/hooks/use-banking";
import { ShinyButton } from "@/components/ui/shiny-button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Lock, Download, Trash2, ArrowLeft, Terminal } from "lucide-react";
import { format } from "date-fns";

export default function Developer() {
  const [code, setCode] = useState("");
  const [authorized, setAuthorized] = useState(false);
  const [data, setData] = useState<any>(null);

  const exportMutation = useDeveloperExport();
  const resetMutation = useDeveloperReset();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (code === "dev123") {
      setAuthorized(true);
      fetchData();
    }
  };

  const fetchData = async () => {
    try {
      const result = await exportMutation.mutateAsync(code);
      setData(result);
    } catch (e) {
      console.error(e);
    }
  };

  const handleReset = async () => {
    if (confirm("ARE YOU SURE? This will wipe all database records.")) {
      await resetMutation.mutateAsync(code);
      fetchData(); // Refresh to empty
    }
  };

  if (!authorized) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="mb-8 flex flex-col items-center gap-4">
          <div className="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center">
            <Lock className="w-8 h-8 text-slate-400" />
          </div>
          <h1 className="text-3xl font-display font-bold text-white">Developer Console</h1>
        </div>
        
        <Card className="w-full max-w-sm bg-slate-900 border-slate-800 text-slate-100">
          <CardHeader>
            <CardTitle>Access Required</CardTitle>
            <CardDescription className="text-slate-400">Enter the system access code (dev123)</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAuth} className="space-y-4">
              <Input 
                type="password" 
                placeholder="Access Code" 
                value={code}
                onChange={e => setCode(e.target.value)}
                className="bg-slate-950 border-slate-800 text-white font-mono"
              />
              <ShinyButton className="w-full bg-blue-600 hover:bg-blue-500 border-none">
                Authenticate
              </ShinyButton>
              <Link href="/">
                <button type="button" className="w-full text-sm text-slate-500 hover:text-slate-300 mt-2">
                  Return to Home
                </button>
              </Link>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-mono">
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Terminal className="w-5 h-5 text-green-500" />
            <span className="font-bold text-lg">System Admin</span>
            <Badge variant="outline" className="border-green-500/50 text-green-500 ml-2">Authenticated</Badge>
          </div>
          <div className="flex items-center gap-3">
            <ShinyButton 
              onClick={fetchData} 
              variant="outline" 
              className="h-9 px-3 border-slate-700 hover:bg-slate-800 text-xs"
            >
              Refresh Data
            </ShinyButton>
            <ShinyButton 
              onClick={handleReset} 
              variant="danger" 
              className="h-9 px-3 text-xs"
            >
              <Trash2 className="w-3 h-3 mr-2" /> Reset Database
            </ShinyButton>
            <Link href="/">
              <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </button>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        {data && (
          <>
            <section className="space-y-4">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                Accounts ({data.accounts.length})
              </h2>
              <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
                <Table>
                  <TableHeader className="bg-slate-950">
                    <TableRow className="border-slate-800 hover:bg-transparent">
                      <TableHead className="text-slate-400">ID</TableHead>
                      <TableHead className="text-slate-400">Account No</TableHead>
                      <TableHead className="text-slate-400">Name</TableHead>
                      <TableHead className="text-slate-400 text-right">Balance</TableHead>
                      <TableHead className="text-slate-400 text-right">PIN</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.accounts.map((acc: any) => (
                      <TableRow key={acc.id} className="border-slate-800 hover:bg-slate-800/50">
                        <TableCell className="font-medium text-slate-500">#{acc.id}</TableCell>
                        <TableCell className="text-blue-400">{acc.accNo}</TableCell>
                        <TableCell>{acc.name}</TableCell>
                        <TableCell className="text-right text-emerald-400">${Number(acc.balance).toFixed(2)}</TableCell>
                        <TableCell className="text-right font-mono text-slate-500">{acc.pin}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-purple-500" />
                Transactions ({data.transactions.length})
              </h2>
              <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-hidden">
                <ScrollArea className="h-[400px]">
                  <Table>
                    <TableHeader className="bg-slate-950 sticky top-0">
                      <TableRow className="border-slate-800 hover:bg-transparent">
                        <TableHead className="text-slate-400">ID</TableHead>
                        <TableHead className="text-slate-400">Type</TableHead>
                        <TableHead className="text-slate-400">From</TableHead>
                        <TableHead className="text-slate-400">To</TableHead>
                        <TableHead className="text-slate-400 text-right">Amount</TableHead>
                        <TableHead className="text-slate-400">Status</TableHead>
                        <TableHead className="text-slate-400 text-right">Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.transactions.map((tx: any) => (
                        <TableRow key={tx.id} className="border-slate-800 hover:bg-slate-800/50">
                          <TableCell className="font-medium text-slate-500">#{tx.id}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="border-slate-700 text-slate-300">
                              {tx.type}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-slate-400">{tx.fromAcc}</TableCell>
                          <TableCell className="text-slate-400">{tx.toAcc || '-'}</TableCell>
                          <TableCell className="text-right text-emerald-400">${Number(tx.amount).toFixed(2)}</TableCell>
                          <TableCell>
                            <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium ${
                              tx.status === 'completed' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-400'
                            }`}>
                              {tx.status}
                            </span>
                          </TableCell>
                          <TableCell className="text-right text-xs text-slate-500">
                            {tx.createdAt ? format(new Date(tx.createdAt), 'MM/dd HH:mm') : '-'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </ScrollArea>
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
}
