import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { 
  type CreateAccountRequest, 
  type DepositWithdrawRequest,
  type TransferRequest,
  type ScheduleTransactionRequest,
  type SmartBalanceRequest,
  type SmartBalanceResponse
} from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

// === ACCOUNTS ===

export function useVerifyAccount() {
  return useMutation({
    mutationFn: async (credentials: { accNo: string; pin: number }) => {
      const res = await fetch(api.accounts.verify.path, {
        method: api.accounts.verify.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials),
        credentials: "include",
      });
      if (!res.ok) {
        if (res.status === 401 || res.status === 404) throw new Error("Invalid Account Number or PIN");
        throw new Error("Verification failed");
      }
      return api.accounts.verify.responses[200].parse(await res.json());
    },
  });
}

export function useCreateAccount() {
  return useMutation({
    mutationFn: async (data: CreateAccountRequest) => {
      const res = await fetch(api.accounts.create.path, {
        method: api.accounts.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create account");
      }
      return api.accounts.create.responses[201].parse(await res.json());
    },
  });
}

export function useAccount(accNo?: string) {
  return useQuery({
    queryKey: [api.accounts.get.path, accNo],
    queryFn: async () => {
      if (!accNo) return null;
      const url = buildUrl(api.accounts.get.path, { accNo });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch account");
      return api.accounts.get.responses[200].parse(await res.json());
    },
    enabled: !!accNo,
  });
}

// === TRANSACTIONS ===

export function useProcessTransaction() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: DepositWithdrawRequest) => {
      const res = await fetch(api.transactions.process.path, {
        method: api.transactions.process.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Transaction failed");
      }
      return api.transactions.process.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({ title: "Success", description: data.message });
      queryClient.invalidateQueries({ queryKey: [api.accounts.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.transactions.history.path] });
    },
    onError: (error: Error) => {
      toast({ title: "Transaction Failed", description: error.message, variant: "destructive" });
    }
  });
}

export function useTransfer() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: TransferRequest) => {
      const res = await fetch(api.transactions.transfer.path, {
        method: api.transactions.transfer.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Transfer failed");
      }
      return api.transactions.transfer.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({ title: "Transfer Successful", description: data.message });
      queryClient.invalidateQueries({ queryKey: [api.accounts.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.transactions.history.path] });
    },
    onError: (error: Error) => {
      toast({ title: "Transfer Failed", description: error.message, variant: "destructive" });
    }
  });
}

export function useScheduleTransaction() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: ScheduleTransactionRequest) => {
      const res = await fetch(api.transactions.schedule.path, {
        method: api.transactions.schedule.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Scheduling failed");
      }
      return api.transactions.schedule.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({ title: "Scheduled", description: data.message });
      // In a real app we'd invalidate scheduled transactions list
    },
    onError: (error: Error) => {
      toast({ title: "Scheduling Failed", description: error.message, variant: "destructive" });
    }
  });
}

export function useTransactionHistory(accNo?: string) {
  return useQuery({
    queryKey: [api.transactions.history.path, accNo],
    queryFn: async () => {
      if (!accNo) return [];
      const url = buildUrl(api.transactions.history.path, { accNo });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch history");
      return api.transactions.history.responses[200].parse(await res.json());
    },
    enabled: !!accNo,
  });
}

// === TOOLS ===

export function useSmartBalance() {
  return useMutation({
    mutationFn: async (data: SmartBalanceRequest) => {
      const res = await fetch(api.tools.smartBalance.path, {
        method: api.tools.smartBalance.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Prediction failed");
      }
      return (await res.json()) as SmartBalanceResponse;
    },
  });
}

// === DEVELOPER ===

export function useDeveloperExport() {
  return useMutation({
    mutationFn: async (code: string) => {
      const res = await fetch(api.tools.developer.export.path, {
        method: api.tools.developer.export.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Export failed");
      return api.tools.developer.export.responses[200].parse(await res.json());
    }
  });
}

export function useDeveloperReset() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (code: string) => {
      const res = await fetch(api.tools.developer.reset.path, {
        method: api.tools.developer.reset.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Reset failed");
      return api.tools.developer.reset.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      toast({ title: "System Reset", description: "All data has been wiped." });
      queryClient.invalidateQueries();
    }
  });
}
