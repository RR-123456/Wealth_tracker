import { useState } from "react";
import { useProcessTransaction, useTransfer, useScheduleTransaction } from "@/hooks/use-banking";
import { useAuth } from "@/context/AuthContext";
import { useLanguage } from "@/context/LanguageContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { ShinyButton } from "@/components/ui/shiny-button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { CalendarIcon, Loader2 } from "lucide-react";
import { z } from "zod";

interface TransactionModalProps {
  type: "DEPOSIT" | "WITHDRAW" | "TRANSFER" | "LOAN_CREDIT" | "LOAN_REPAY";
  trigger: React.ReactNode;
}

export function TransactionModal({ type, trigger }: TransactionModalProps) {
  const { account } = useAuth();
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [toAcc, setToAcc] = useState("");
  const [isScheduled, setIsScheduled] = useState(false);
  const [date, setDate] = useState<Date>();

  const processMutation = useProcessTransaction();
  const transferMutation = useTransfer();
  const scheduleMutation = useScheduleTransaction();

  const isPending = processMutation.isPending || transferMutation.isPending || scheduleMutation.isPending;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!account) return;

    try {
      if (isScheduled && date) {
        await scheduleMutation.mutateAsync({
          fromAcc: account.accNo,
          pin: account.pin,
          type: type as any,
          amount: parseFloat(amount),
          toAcc: type === 'TRANSFER' ? toAcc : undefined,
          scheduledFor: date.toISOString()
        });
      } else if (type === 'TRANSFER') {
        await transferMutation.mutateAsync({
          fromAcc: account.accNo,
          pin: account.pin,
          toAcc,
          amount: parseFloat(amount),
        });
      } else {
        await processMutation.mutateAsync({
          accNo: account.accNo,
          pin: account.pin,
          type: type as any,
          amount: parseFloat(amount),
        });
      }
      setOpen(false);
      setAmount("");
      setToAcc("");
      setIsScheduled(false);
      setDate(undefined);
    } catch (error) {
      // Handled by mutation hook
    }
  };

  const typeLabels = {
    DEPOSIT: t("deposit"),
    WITHDRAW: t("withdraw"),
    TRANSFER: t("transfer"),
    LOAN_CREDIT: t("loanCredit"),
    LOAN_REPAY: t("loanRepay")
  };

  const title = isScheduled ? `${t("scheduleLater")} - ${typeLabels[type]}` : typeLabels[type];
  const description = isScheduled 
    ? `${t("scheduleLater")} ${typeLabels[type].toLowerCase()}.`
    : `${typeLabels[type]} ${t("confirm").toLowerCase()}.`;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-md bg-white/95 backdrop-blur-xl border-white/20">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">{t("amount")} ($)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                min="0.01"
                step="0.01"
                required
                className="text-lg font-mono"
              />
            </div>

            {type === 'TRANSFER' && (
              <div className="space-y-2">
                <Label htmlFor="toAcc">{t("accountNumber")}</Label>
                <Input
                  id="toAcc"
                  placeholder={t("accountNumber")}
                  value={toAcc}
                  onChange={(e) => setToAcc(e.target.value)}
                  required
                />
              </div>
            )}

            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-50 border border-slate-100">
              <div className="space-y-0.5">
                <Label className="text-base">{t("scheduleLater")}</Label>
                <p className="text-sm text-slate-500">{t("executeAuto")}</p>
              </div>
              <Switch checked={isScheduled} onCheckedChange={setIsScheduled} />
            </div>

            {isScheduled && (
              <div className="space-y-2 animate-in fade-in slide-in-from-top-2">
                <Label>{t("dueDate")}</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      className={cn(
                        "w-full justify-start text-left font-normal h-10 rounded-md border border-input bg-background px-3 py-2 text-sm flex items-center gap-2",
                        !date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, "PPP") : <span>{t("pickDate")}</span>}
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            )}
          </div>

          <ShinyButton 
            type="submit" 
            className="w-full" 
            disabled={isPending}
          >
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                {t("processing")}
              </>
            ) : (
              isScheduled ? t("confirm") : `${t("confirm")} ${typeLabels[type]}`
            )}
          </ShinyButton>
        </form>
      </DialogContent>
    </Dialog>
  );
}
