import { useState } from "react";
import { useSmartBalance } from "@/hooks/use-banking";
import { useLanguage } from "@/context/LanguageContext";
import { ShinyButton } from "./ui/shiny-button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calculator, CalendarIcon, TrendingUp, TrendingDown, DollarSign } from "lucide-react";
import { cn } from "@/lib/utils";

interface SmartBalanceCardProps {
  accNo: string;
  pin: number;
}

export function SmartBalanceCard({ accNo, pin }: SmartBalanceCardProps) {
  const [date, setDate] = useState<Date>();
  const { t } = useLanguage();
  const { mutate: predict, isPending, data, error } = useSmartBalance();

  const handlePredict = () => {
    if (!date) return;
    predict({
      accNo,
      pin,
      targetDate: date.toISOString(),
    });
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-6 text-white shadow-xl overflow-hidden relative">
      {/* Abstract Background Shapes */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-white/10 rounded-xl">
            <Calculator className="w-6 h-6 text-blue-300" />
          </div>
          <div>
            <h3 className="text-xl font-bold font-display">{t("smartBalance")}</h3>
            <p className="text-slate-400 text-sm">{t("aiPrediction")}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <button
                  className={cn(
                    "flex-1 justify-start text-left font-normal h-12 rounded-xl bg-white/5 border border-white/10 px-4 text-sm flex items-center gap-2 hover:bg-white/10 transition-colors",
                    !date && "text-slate-400"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : <span>{t("pickDate")}</span>}
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  disabled={(date) => date < new Date()}
                  initialFocus
                />
              </PopoverContent>
            </Popover>

            <ShinyButton 
              onClick={handlePredict} 
              disabled={!date || isPending}
              className="bg-blue-500 hover:bg-blue-600 text-white shadow-blue-500/25"
            >
              {isPending ? t("processing") : t("predict")}
            </ShinyButton>
          </div>

          {error && (
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-200 text-sm">
              {error.message}
            </div>
          )}

          {data && (
            <div className="mt-6 space-y-4 animate-in fade-in slide-in-from-bottom-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl bg-white/5 border border-white/10 col-span-2">
                  <div className="flex justify-between items-start mb-1">
                    <p className="text-slate-400 text-xs uppercase tracking-wider font-semibold">{t("predictedBalance")}</p>
                    <div className="px-2 py-0.5 bg-blue-500/20 text-blue-300 text-[10px] font-bold rounded-full border border-blue-500/30">
                      {data.confidence.toFixed(0)}% CONFIDENCE
                    </div>
                  </div>
                  <div className="text-3xl font-bold font-mono tracking-tight text-white">
                    ${Number(data.predictedBalance).toFixed(2)}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <p className="text-slate-400 text-[10px] uppercase font-bold mb-1">Matrix Balance</p>
                  <p className="text-lg font-mono font-bold">${data.matrixValues.calculated_balance.toFixed(2)}</p>
                </div>
                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <p className="text-slate-400 text-[10px] uppercase font-bold mb-1">ML Adjustment</p>
                  <p className="text-lg font-mono font-bold text-blue-400">+${data.matrixValues.ml_adjustment.toFixed(2)}</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-3">
                <p className="text-slate-400 text-xs uppercase tracking-wider font-semibold">Financial Snapshot (3m Avg)</p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <p className="text-[10px] text-slate-500 uppercase">Monthly In/Out</p>
                    <p className="text-sm font-mono text-green-400">+${data.avgMonthlyIncoming.toFixed(2)}</p>
                    <p className="text-sm font-mono text-red-400">-${data.avgMonthlyOutgoing.toFixed(2)}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] text-slate-500 uppercase">Daily In/Out</p>
                    <p className="text-sm font-mono text-green-400">+${data.avgDailyIncoming.toFixed(2)}</p>
                    <p className="text-sm font-mono text-red-400">-${data.avgDailyOutgoing.toFixed(2)}</p>
                  </div>
                </div>
              </div>

              {data.activeLoan && (
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
                  <p className="text-amber-400 text-xs uppercase tracking-wider font-semibold mb-2">{t("loanInfo")}</p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-amber-100/70">{t("principal")}:</div>
                    <div className="text-right font-mono">${data.activeLoan.amount.toFixed(2)}</div>
                    <div className="text-amber-100/70">{t("interest")} (5%):</div>
                    <div className="text-right font-mono">${data.activeLoan.interest.toFixed(2)}</div>
                    {data.activeLoan.penalty > 0 && (
                      <>
                        <div className="text-red-400">{t("penalty")} (2%):</div>
                        <div className="text-right font-mono text-red-400">${data.activeLoan.penalty.toFixed(2)}</div>
                      </>
                    )}
                    <div className="text-amber-100 font-bold pt-1 border-t border-amber-500/20">{t("totalDue")}:</div>
                    <div className="text-right font-mono font-bold pt-1 border-t border-amber-500/20">${data.activeLoan.totalDue.toFixed(2)}</div>
                  </div>
                  <p className="text-[10px] text-amber-100/50 mt-2 italic text-center">{t("dueDate")}: {format(new Date(data.activeLoan.dueDate), "PPP")}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/20">
                  <div className="flex items-center gap-2 mb-1">
                    <TrendingUp className="w-4 h-4 text-green-400" />
                    <span className="text-xs font-medium text-green-400">{t("incoming")}</span>
                  </div>
                  <p className="text-lg font-bold text-green-100">+${data.scheduledDeposits}</p>
                </div>

                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20">
                  <div className="flex items-center gap-2 mb-1">
                    <TrendingDown className="w-4 h-4 text-red-400" />
                    <span className="text-xs font-medium text-red-400">{t("outgoing")}</span>
                  </div>
                  <p className="text-lg font-bold text-red-100">-${data.scheduledWithdrawals}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
