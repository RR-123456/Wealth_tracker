import { createContext, useContext, useState, ReactNode } from "react";

type Language = "en" | "ta";

interface Translations {
  [key: string]: {
    en: string;
    ta: string;
  };
}

const translations: Translations = {
  welcome: { en: "Welcome", ta: "வரவேற்பு" },
  totalBalance: { en: "Total Balance", ta: "மொத்த இருப்பு" },
  deposit: { en: "Deposit", ta: "டெபாசிட்" },
  withdraw: { en: "Withdraw", ta: "பணம் எடுத்தல்" },
  transfer: { en: "Transfer", ta: "பரிமாற்றம்" },
  loanCredit: { en: "Get Loan (Credit)", ta: "கடன் பெறுதல்" },
  loanRepay: { en: "Repay Loan", ta: "கடன் திருப்பிச் செலுத்துதல்" },
  recentTransactions: { en: "Recent Transactions", ta: "சமீபத்திய பரிமாற்றங்கள்" },
  smartBalance: { en: "Smart Balance", ta: "ஸ்மார்ட் இருப்பு" },
  aiPrediction: { en: "AI-Powered Future Prediction", ta: "AI-மூலம் எதிர்கால கணிப்பு" },
  pickDate: { en: "Pick a future date", ta: "எதிர்கால தேதியைத் தேர்ந்தெடுக்கவும்" },
  predict: { en: "Predict", ta: "கணிக்கவும்" },
  predictedBalance: { en: "Predicted Balance", ta: "கணிக்கப்பட்ட இருப்பு" },
  incoming: { en: "Incoming", ta: "உள்வரும்" },
  outgoing: { en: "Outgoing", ta: "வெளியே செல்லும்" },
  activeLoan: { en: "ACTIVE LOAN", ta: "செயலில் உள்ள கடன்" },
  loanInfo: { en: "Active Loan Info", ta: "கடன் விவரங்கள்" },
  principal: { en: "Principal", ta: "அசல்" },
  interest: { en: "Interest", ta: "வட்டி" },
  penalty: { en: "Penalty", ta: "அபராதம்" },
  totalDue: { en: "Total Due", ta: "மொத்த நிலுவை" },
  dueDate: { en: "Due Date", ta: "கடைசி தேதி" },
  logout: { en: "Logout", ta: "வெளியேறு" },
  accountNumber: { en: "Account Number", ta: "கணக்கு எண்" },
  pin: { en: "PIN", ta: "பின் எண்" },
  login: { en: "Login", ta: "உள்நுழை" },
  createAccount: { en: "Create Account", ta: "கணக்கை உருவாக்கு" },
  name: { en: "Name", ta: "பெயர்" },
  initialBalance: { en: "Initial Balance", ta: "தொடக்க இருப்பு" },
  amount: { en: "Amount", ta: "தொகை" },
  confirm: { en: "Confirm", ta: "உறுதிப்படுத்து" },
  processing: { en: "Processing...", ta: "செயலாக்கம்..." },
  scheduleLater: { en: "Schedule for later?", ta: "பிறகு திட்டமிடவா?" },
  executeAuto: { en: "Execute automatically on a future date", ta: "எதிர்காலத்தில் தானாகவே செயல்படும்" },
  language: { en: "Language", ta: "மொழி" }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("en");

  const t = (key: string) => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
