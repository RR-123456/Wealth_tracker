## Packages
date-fns | formatting dates for transactions
recharts | visualizing smart balance predictions
framer-motion | smooth page transitions and micro-interactions
clsx | utility for conditional classes
tailwind-merge | utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Plus Jakarta Sans", "sans-serif"],
}
