import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

const SERVICE_CHARGE = 1.0;
const SMS_COST = 0.5;
const PRE_SCHEDULE_COST = 0.2;
const INTEREST_RATE = 0.05;
const PENALTY_RATE = 0.02;
const LOAN_DAYS = 30;
const DEVELOPER_CODE = "dev123";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post(api.accounts.create.path, async (req, res) => {
    try {
      const input = api.accounts.create.input.parse(req.body);
      const existing = await storage.getAccountByNo(input.accNo);
      if (existing) {
        return res.status(409).json({ message: "Account number already exists" });
      }
      const account = await storage.createAccount(input);
      res.status(201).json(account);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.get(api.accounts.list.path, async (req, res) => {
    const accounts = await storage.getAllAccounts();
    res.json(accounts);
  });

  app.get(api.accounts.get.path, async (req, res) => {
    const account = await storage.getAccountByNo(req.params.accNo);
    if (!account) {
      return res.status(404).json({ message: "Account not found" });
    }
    res.json(account);
  });

  app.post(api.accounts.verify.path, async (req, res) => {
    const { accNo, pin } = req.body;
    const account = await storage.getAccountByNo(accNo);
    if (account && account.pin === pin) {
      res.json({ verified: true, account });
    } else {
      res.json({ verified: false });
    }
  });

  app.post(api.transactions.process.path, async (req, res) => {
    try {
      const { accNo, pin, amount, type } = req.body;
      const account = await storage.getAccountByNo(accNo);
      
      if (!account || account.pin !== pin) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      let currentBalance = Number(account.balance);
      let currentLoan = Number(account.loanAmount);
      let fee = 0;

      if (type === "WITHDRAW") {
        fee = SERVICE_CHARGE;
        if (currentBalance < amount + fee) {
          return res.status(400).json({ message: "Insufficient funds" });
        }
        currentBalance -= (amount + fee);
      } else if (type === "DEPOSIT") {
        currentBalance += amount;
      } else if (type === "LOAN_CREDIT") {
        if (currentLoan > 0) {
          return res.status(400).json({ message: "Existing loan must be repaid first." });
        }
        currentLoan = amount;
        await storage.updateAccount(account.id, { 
          loanAmount: currentLoan.toString(),
          loanStartDate: new Date()
        });
        // Logic says loan is "credited", usually to savings in these scripts
        currentBalance += amount; 
      } else if (type === "LOAN_REPAY") {
        if (currentLoan === 0) {
          return res.status(400).json({ message: "No active loan." });
        }
        
        const interest = currentLoan * INTEREST_RATE;
        let totalDue = currentLoan + interest;
        const dueDate = new Date(account.loanStartDate!);
        dueDate.setDate(dueDate.getDate() + LOAN_DAYS);
        
        if (new Date() > dueDate) {
          totalDue += (currentLoan * PENALTY_RATE);
        }

        if (currentBalance < totalDue) {
          return res.status(400).json({ message: `Insufficient savings. Total due: ${totalDue.toFixed(2)}` });
        }

        currentBalance -= totalDue;
        await storage.updateAccount(account.id, { 
          loanAmount: "0",
          loanStartDate: null
        });
      }

      await storage.updateAccount(account.id, { balance: currentBalance.toFixed(2) });
      await storage.createTransaction({
        type,
        fromAcc: accNo,
        toAcc: accNo,
        amount: amount.toString(),
        fee: fee.toString(),
        isScheduled: false,
        status: 'completed',
        executedAt: new Date()
      });

      res.json({ success: true, newBalance: currentBalance, message: `${type} successful` });
    } catch (err) {
      res.status(500).json({ message: "Transaction failed" });
    }
  });

  app.post(api.transactions.transfer.path, async (req, res) => {
    try {
      const { fromAcc, pin, toAcc, amount } = req.body;
      const sourceAcc = await storage.getAccountByNo(fromAcc);
      const destAcc = await storage.getAccountByNo(toAcc);

      if (!sourceAcc || sourceAcc.pin !== pin) {
        return res.status(401).json({ message: "Invalid sender credentials" });
      }
      if (!destAcc) {
        return res.status(400).json({ message: "Receiver account not found" });
      }

      const fee = SERVICE_CHARGE;
      const totalDeduction = amount + fee;
      const currentBalance = Number(sourceAcc.balance);

      if (currentBalance < totalDeduction) {
        return res.status(400).json({ message: "Insufficient funds" });
      }

      await storage.updateAccount(sourceAcc.id, { balance: (currentBalance - totalDeduction).toFixed(2) });
      await storage.updateAccount(destAcc.id, { balance: (Number(destAcc.balance) + amount).toFixed(2) });

      await storage.createTransaction({
        type: "TRANSFER",
        fromAcc: fromAcc,
        toAcc: toAcc,
        amount: amount.toString(),
        fee: fee.toString(),
        isScheduled: false,
        status: 'completed',
        executedAt: new Date()
      });

      res.json({ success: true, newBalance: currentBalance - totalDeduction, message: "Transfer successful" });
    } catch (err) {
      res.status(500).json({ message: "Transfer failed" });
    }
  });

  app.post(api.transactions.schedule.path, async (req, res) => {
    try {
      const { fromAcc, pin, type, toAcc, amount, scheduledFor } = req.body;
      const account = await storage.getAccountByNo(fromAcc);
      
      if (!account || account.pin !== pin) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const fee = SERVICE_CHARGE + SMS_COST + PRE_SCHEDULE_COST;
      
      const tx = await storage.createTransaction({
        type,
        fromAcc,
        toAcc: toAcc || fromAcc,
        amount: amount.toString(),
        fee: fee.toString(),
        isScheduled: true,
        scheduledFor: new Date(scheduledFor),
        status: 'pending'
      });

      res.status(201).json({ message: "Transaction scheduled", id: tx.id });
    } catch (err) {
      res.status(500).json({ message: "Scheduling failed" });
    }
  });

  app.post(api.tools.smartBalance.path, async (req, res) => {
    const { accNo, pin, targetDate } = req.body;
    const account = await storage.getAccountByNo(accNo);
    
    if (!account || account.pin !== pin) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const allTransactions = await storage.getAllTransactions(); // We need history for averages
    const scheduled = await storage.getScheduledTransactions(accNo);
    const targetTime = new Date(targetDate).getTime();
    const now = new Date();
    const nowTime = now.getTime();
    const threeMonthsAgo = new Date(nowTime - 90 * 86400 * 1000);
    const weekAgo = new Date(nowTime - 7 * 86400 * 1000);
    
    // Matrix Calculator logic
    let scheduled_transfers = 0;
    let taxes = 0;
    let penalties = 0;
    let credit_amt = 0; 
    let interest = 0;
    let recent_transfers: number[] = [];

    const applicableScheduled = scheduled.filter(tx => {
      const txTime = new Date(tx.scheduledFor!).getTime();
      return txTime <= targetTime && tx.status === 'pending';
    });

    for (const tx of applicableScheduled) {
      const amt = Number(tx.amount);
      scheduled_transfers += amt;
      taxes += amt * 0.02; // TAX_RATE from python script
      // Simplified interest/penalty logic based on python script requirements
      if (tx.status !== 'completed' && new Date(tx.scheduledFor!).getTime() + 30*86400*1000 < nowTime) {
        penalties += amt * 0.15;
      }
    }

    // ML Adjustment from last week's transfers to this account
    const weekHistory = allTransactions.filter(tx => 
      tx.toAcc === accNo && 
      tx.type === 'TRANSFER' && 
      tx.executedAt && 
      new Date(tx.executedAt) >= weekAgo
    );
    recent_transfers = weekHistory.map(tx => Number(tx.amount));
    let ml_adjustment = recent_transfers.length > 0 
      ? (recent_transfers.reduce((a, b) => a + b, 0) / recent_transfers.length) * 0.1 
      : 0;

    const calculated_balance = Number(account.balance) - scheduled_transfers - taxes - credit_amt + interest - penalties + ml_adjustment;

    // Smart Balance Predictor (Averages)
    const historyIncoming = allTransactions.filter(tx => 
      tx.toAcc === accNo && 
      tx.executedAt && 
      new Date(tx.executedAt) >= threeMonthsAgo && 
      new Date(tx.executedAt) <= now
    ).map(tx => Number(tx.amount));

    const historyOutgoing = allTransactions.filter(tx => 
      tx.fromAcc === accNo && 
      tx.executedAt && 
      new Date(tx.executedAt) >= threeMonthsAgo && 
      new Date(tx.executedAt) <= now
    ).map(tx => Number(tx.amount));

    const totalIn = historyIncoming.reduce((a, b) => a + b, 0);
    const totalOut = historyOutgoing.reduce((a, b) => a + b, 0);
    const avgMonthlyIncoming = totalIn / 3;
    const avgMonthlyOutgoing = totalOut / 3;
    const avgDailyIncoming = avgMonthlyIncoming / 30;
    const avgDailyOutgoing = avgMonthlyOutgoing / 30;

    const daysAhead = Math.max(0, Math.ceil((targetTime - nowTime) / (1000 * 60 * 60 * 24)));
    const fractionalMonths = daysAhead / 30;
    const netAvgChange = avgMonthlyIncoming - avgMonthlyOutgoing;
    const predictedBalance = calculated_balance + (netAvgChange * fractionalMonths);

    // Confidence logic
    let confidence = 85; // Base confidence
    if (historyIncoming.length < 5) confidence -= 20;
    if (daysAhead > 30) confidence -= (daysAhead - 30) / 2;
    confidence = Math.max(50, Math.min(100, confidence));

    const loanAmount = Number(account.loanAmount);
    let activeLoanInfo = null;
    if (loanAmount > 0) {
      const interestAmt = loanAmount * INTEREST_RATE;
      let totalDue = loanAmount + interestAmt;
      const dueDate = new Date(account.loanStartDate!);
      dueDate.setDate(dueDate.getDate() + LOAN_DAYS);
      let penalty = 0;
      if (now > dueDate) {
        penalty = loanAmount * PENALTY_RATE;
        totalDue += penalty;
      }
      activeLoanInfo = {
        amount: loanAmount,
        interest: interestAmt,
        penalty,
        totalDue,
        dueDate: dueDate.toISOString()
      };
    }

    res.json({
      currentBalance: Number(account.balance),
      scheduledDeposits: applicableScheduled.filter(tx => tx.type === 'DEPOSIT').reduce((sum, tx) => sum + Number(tx.amount), 0),
      scheduledWithdrawals: applicableScheduled.filter(tx => tx.type !== 'DEPOSIT').reduce((sum, tx) => sum + Number(tx.amount), 0),
      projectedFees: taxes + penalties,
      predictedBalance,
      confidence,
      avgMonthlyIncoming,
      avgMonthlyOutgoing,
      avgDailyIncoming,
      avgDailyOutgoing,
      activeLoan: activeLoanInfo,
      matrixValues: {
        scheduled_transfers,
        taxes,
        credit_amt,
        interest,
        penalties,
        ml_adjustment,
        calculated_balance
      }
    });
  });

  app.post(api.tools.developer.export.path, async (req, res) => {
    if (req.body.code !== DEVELOPER_CODE) {
      return res.status(403).json({ message: "Access denied" });
    }
    const accounts = await storage.getAllAccounts();
    const transactions = await storage.getAllTransactions();
    res.json({ accounts, transactions });
  });

  app.post(api.tools.developer.reset.path, async (req, res) => {
    if (req.body.code !== DEVELOPER_CODE) {
      return res.status(403).json({ message: "Access denied" });
    }
    await storage.resetAll();
    res.json({ message: "All data cleared" });
  });

  const existing = await storage.getAllAccounts();
  if (existing.length === 0) {
    await storage.createAccount({ accNo: "1001", name: "John Doe", initialBalance: 5000, pin: 1234 });
    await storage.createAccount({ accNo: "1002", name: "Jane Smith", initialBalance: 1500, pin: 4321 });
  }

  return httpServer;
}
