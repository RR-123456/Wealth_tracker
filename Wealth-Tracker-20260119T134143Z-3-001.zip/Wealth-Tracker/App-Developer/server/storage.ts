import { accounts, transactions, type Account, type Transaction, type CreateAccountRequest } from "@shared/schema";
import { db } from "./db";
import { eq, sql, and } from "drizzle-orm";

export interface IStorage {
  createAccount(account: CreateAccountRequest): Promise<Account>;
  getAccountByNo(accNo: string): Promise<Account | undefined>;
  getAllAccounts(): Promise<Account[]>;
  updateAccount(id: number, updates: Partial<Account>): Promise<Account>;
  resetAll(): Promise<void>;
  createTransaction(tx: Partial<Transaction>): Promise<Transaction>;
  getTransactions(accNo: string): Promise<Transaction[]>;
  getAllTransactions(): Promise<Transaction[]>;
  getTransactionById(id: number): Promise<Transaction | undefined>;
  cancelScheduledTransaction(id: number): Promise<void>;
  getScheduledTransactions(accNo: string): Promise<Transaction[]>;
}

export class DatabaseStorage implements IStorage {
  async createAccount(insertAccount: CreateAccountRequest): Promise<Account> {
    const [account] = await db.insert(accounts).values({
      ...insertAccount,
      balance: insertAccount.initialBalance?.toString() || "0",
      loanAmount: "0",
    }).returning();
    return account;
  }

  async getAccountByNo(accNo: string): Promise<Account | undefined> {
    const [account] = await db.select().from(accounts).where(eq(accounts.accNo, accNo));
    return account;
  }

  async getAllAccounts(): Promise<Account[]> {
    return await db.select().from(accounts);
  }

  async updateAccount(id: number, updates: Partial<Account>): Promise<Account> {
    const [account] = await db.update(accounts)
      .set(updates)
      .where(eq(accounts.id, id))
      .returning();
    return account;
  }

  async resetAll(): Promise<void> {
    await db.delete(transactions);
    await db.delete(accounts);
  }

  async createTransaction(tx: Partial<Transaction>): Promise<Transaction> {
    const [transaction] = await db.insert(transactions).values(tx as any).returning();
    return transaction;
  }

  async getTransactions(accNo: string): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .where(
        and(
          sql`${transactions.fromAcc} = ${accNo} OR ${transactions.toAcc} = ${accNo}`,
          eq(transactions.isScheduled, false)
        )
      )
      .orderBy(sql`${transactions.createdAt} DESC`);
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return await db.select().from(transactions).orderBy(sql`${transactions.createdAt} DESC`);
  }

  async getTransactionById(id: number): Promise<Transaction | undefined> {
    const [tx] = await db.select().from(transactions).where(eq(transactions.id, id));
    return tx;
  }

  async cancelScheduledTransaction(id: number): Promise<void> {
    await db.update(transactions)
      .set({ status: 'cancelled' })
      .where(eq(transactions.id, id));
  }

  async getScheduledTransactions(accNo: string): Promise<Transaction[]> {
    return await db.select().from(transactions)
      .where(
        and(
          eq(transactions.fromAcc, accNo),
          eq(transactions.isScheduled, true),
          eq(transactions.status, 'pending')
        )
      );
  }
}

export const storage = new DatabaseStorage();
